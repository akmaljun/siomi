<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class UpdateDataInvestorRequest extends Request {

	/**
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize()
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array
	 */
	public function rules()
	{
		return [
            'user_id' => 'required', 
            'nama_lengkap' => 'required', 
            'tempat_lahir' => 'required', 
            'tanggal_lahir' => 'required', 
            'jenis_kelamin' => 'required', 
            'agama' => 'required', 
            'status_pernikahan' => 'required', 
            'nama_suami/istri' => 'required', 
            'pendidikan' => 'required', 
            'pekerjaan' => 'required', 
            'pendapatan_pertahun' => 'required', 
            'sumber_pendapatan' => 'required', 
            'tujuan_investasi' => 'required', 
            'handphone' => 'required', 
            'telepon' => 'required', 
            'email' => 'required|unique:datainvestor,email,'.$this->datainvestor, 
            'status' => 'required', 
            
		];
	}
}
