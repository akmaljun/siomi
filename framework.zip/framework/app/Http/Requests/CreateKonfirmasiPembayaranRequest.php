<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class CreateKonfirmasiPembayaranRequest extends Request {

	/**
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize()
	{
		return true;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array
	 */
	public function rules()
	{
		return [
            'nomor_rekening' => 'required', 
            'nama_pemegang_rekening' => 'required', 
            'nama_bank' => 'required', 
            'cabang' => 'required', 
            'bank_penerima' => 'required', 
            'bukti_pembayaran' => 'required', 
            'kode_konfirmasi' => 'required', 
            
		];
	}
}
