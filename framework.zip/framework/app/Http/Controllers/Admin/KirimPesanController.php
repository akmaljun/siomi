<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\KirimPesan;
use App\Http\Requests\CreateKirimPesanRequest;
use App\Http\Requests\UpdateKirimPesanRequest;
use Illuminate\Http\Request;
use DB;
use App\Role;
use App\User;


class KirimPesanController extends Controller {

	/**
	 * Display a listing of kirimpesan
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	
	public function index(Request $request)
    {
        $kirimpesan = KirimPesan::with("user")->get();
        //$myRole = Auth::user()->role_id;
		//if($myRole == 3){
			return view('admin.kirimpesan.index', compact('kirimpesan'));
		//}
	}

	/**
	 * Show the form for creating a new kirimpesan
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $user = User::lists("name", "id")->prepend('Please select', '');		
	    return view('admin.kirimpesan.create', compact("user"));
	}

	/**
	 * Store a newly created kirimpesan in storage.
	 *
     * @param CreateKirimPesanRequest|Request $request
	 */
	public function store(CreateKirimPesanRequest $request)
	{
	    
		KirimPesan::create($request->all());

		return redirect()->route('admin.kirimpesan.index');
	}

	/**
	 * Show the form for editing the specified kirimpesan.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$kirimpesan = KirimPesan::find($id);
	    $user = User::lists("name", "id")->prepend('Please select', '');
		return view('admin.kirimpesan.edit', compact('kirimpesan', "user"));
	}

	/**
	 * Update the specified kirimpesan in storage.
     * @param UpdateKirimPesanRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateKirimPesanRequest $request)
	{
		$kirimpesan = KirimPesan::findOrFail($id);        
		$kirimpesan->update($request->all());

		return redirect()->route('admin.kirimpesan.index');
	}

	/**
	 * Remove the specified kirimpesan from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		KirimPesan::destroy($id);

		return redirect()->route('admin.kirimpesan.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            KirimPesan::destroy($toDelete);
        } else {
            KirimPesan::whereNotNull('id')->delete();
        }
        return redirect()->route('admin.kirimpesan.index');
    }
}
