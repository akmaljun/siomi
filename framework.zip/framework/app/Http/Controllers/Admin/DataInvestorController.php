<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\DataInvestor;
use App\Http\Requests\CreateDataInvestorRequest;
use App\Http\Requests\UpdateDataInvestorRequest;
use Illuminate\Http\Request;
use App\Rekening;
use App\User;
use Illuminate\Support\Facades\Hash;
use Auth;
use App\Pembelian;
use App\Penjemputan;

class DataInvestorController extends Controller {

	/**
	 * Display a listing of datainvestor
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        

  if(Auth::user()->role_id == 4){

  	$id = Auth::user()->id;
 
  	$datainvestor = User::with('investor')->where('role_id',6)->get();
  	$pembelian = Pembelian::where('user_id',$id)->get();
  	$penjemputan = Penjemputan::where('user_id',$id)->get();

return view('admin.datainvestor.index1', compact('datainvestor','pembelian','penjemputan'));

	  }else {
        $datainvestor = DataInvestor::all();
  		
		return view('admin.datainvestor.index', compact('datainvestor'));
	}}

	/**
	 * Show the form for creating a new datainvestor
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    
	    return view('daftarinvestor');
	}
	
	 public function aktivasi($id)
    {
    	
        $user = User::where('id',$id)->update(['role_id'=>2]);

     return redirect()->back();
    }

	/**
	 * Store a newly created datainvestor in storage.
	 *
     * @param CreateDataInvestorRequest|Request $request
	 */
	public function store(CreateDataInvestorRequest $request)
	{
	  	
   	
        Investor::create($request->all());
        $investor = Investor::latest()->first();
        $id = $investor['id'];
        $password = str_random(5);
        echo $password;
		$rekening = new Rekening();
		$rekening->datainvestor_id = $id;
		$rekening->nomor_rekening = $request['nomor_rekening'];
		$rekening->jenis_kurs = $request['jenis_kurs'];
		$rekening->nama_pemilik_rekening = $request['nama_pemilik_rekening'];
		$rekening->up = $request['up'];
		$rekening->nama = $request['nama'];
		$rekening->cabang = $request['cabang'];
		$rekening->kode_bank = $request['kode_bank'];
		$rekening->save();
		
		$user = new User();
		$user->role_id = 2;
		$user->name = $request['nama_lengkap'];
		$user->email = $request['email'];
		$user->password = Hash::make($password);
		$user->status_id = 1;
	
		$user->save();

		
	}

	/**
	 * Show the form for editing the specified datainvestor.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$datainvestor = DataInvestor::find($id);
	    $user = User::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.datainvestor.edit', compact('datainvestor', "user"));
	}

	/**
	 * Update the specified datainvestor in storage.
     * @param UpdateDataInvestorRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateDataInvestorRequest $request)
	{
		$datainvestor = DataInvestor::findOrFail($id);

        

		$datainvestor->update($request->all());

		return redirect()->route('admin.datainvestor.index');
	}

	/**
	 * Remove the specified datainvestor from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		DataInvestor::destroy($id);

		return redirect()->route('admin.datainvestor.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            DataInvestor::destroy($toDelete);
        } else {
            DataInvestor::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.datainvestor.index');
    }

}
