<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Pembelian;
use App\Http\Requests\CreatePembelianRequest;
use App\Http\Requests\UpdatePembelianRequest;
use Illuminate\Http\Request;
use App\User;
use App\Reksadana;
use App\KonfirmasiPembayaran;
use Mail;
use Auth;
use PDF;
use App;


class PembelianController extends Controller {

	/**
	 * Display a listing of pembelian
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {


	$id = auth::user()->id;
	$pembelian = Pembelian::where('user_id',$id)->first();
	$idpembelian =  $pembelian['id'];
	
	if(Auth::user()->role_id == 6){

			if($pembelian){
			
			$pembelian = Pembelian::where('id',$idpembelian)->get();
		
	return view('admin.pembelian.index', compact('pembelian'));
			
		}
else{

	return redirect()->route('admin.pembelian.create');
}}

else{
	
        $pembelian = Pembelian::with("reksadana")->with("user")->with("konfirmasipembayaran")->get();
        
		return view('admin.pembelian.index', compact('pembelian'));
}
	}

	/**
	 * Show the form for creating a new pembelian
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $reksadana = Reksadana::lists("nama", "id")->prepend('Please select', '');
		$user = User::lists("id", "id")->prepend('Please select', '');
		$konfirmasipembayaran = KonfirmasiPembayaran::lists("id", "id")->prepend('Please select', '');
		$matauang = [null=>'Please select','Rupiah'=>'Rupiah','Dollar'=>'Dollar'];
		$penempatan = [null=>'Please select','Tambah Saldo'=>'Tambah Saldo','Buka Rekening'=>'Buka Rekening'];


	    
	    return view('admin.pembelian.create', compact("reksadana", "user", "konfirmasipembayaran","matauang","penempatan"));
	}

	/**
	 * Store a newly created pembelian in storage.
	 *
     * @param CreatePembelianRequest|Request $request
	 */
	public function store(CreatePembelianRequest $request)
	{
		
	    $kode_konfirmasi = str_random(5);
	    $request['kode_konfirmasi']= $kode_konfirmasi;
	    $id = $request['user_id'];

	    $user = User::findOrFail($id);
		Pembelian::create($request->all());

		Mail::send('emails.konfirmasi', ['user' => $user,'kode_konfirmasi'=>$kode_konfirmasi], function ($m) use ($user) {
       	$m->from('oso@mail.com', 'Operasional Tim');
        $m->to($user->email, $user->name)->subject('Kode Konfirmasi');
        });


			return redirect()->route('admin.pembelian.index');
	}

	/**
	 * Show the form for editing the specified pembelian.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */

	 	public function makepdf($id)
	{	

	return PDF::loadFile(public_path().'/penjualan.html')->stream('download.pdf');

	}


	public function edit($id)
	{
		$pembelian = Pembelian::find($id);
	    $reksadana = Reksadana::lists("id", "id")->prepend('Please select', '');
		$user = User::lists("id", "id")->prepend('Please select', '');
	$konfirmasipembayaran = KonfirmasiPembayaran::lists("id", "id")->prepend('Please select', '');
	$status = ['Disetujui'=>'Setujui','Ditolak'=>'Tolak'];

	    
		return view('admin.pembelian.edit', compact('pembelian', "reksadana", "user", "konfirmasipembayaran","status"));
	}

	/**
	 * Update the specified pembelian in storage.
     * @param UpdatePembelianRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdatePembelianRequest $request)
	{
		$pembelian = Pembelian::findOrFail($id);
		$pembelian->update($request->all());
		
		return redirect()->route('admin.pembelian.index');
		
	}

	/**
	 * Remove the specified pembelian from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Pembelian::destroy($id);

		return redirect()->route('admin.pembelian.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Pembelian::destroy($toDelete);
        } else {
            Pembelian::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.pembelian.index');
    }

}
