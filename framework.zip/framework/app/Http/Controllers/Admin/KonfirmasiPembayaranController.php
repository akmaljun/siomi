<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\KonfirmasiPembayaran;
use App\Pembelian;
use App\Http\Requests\CreateKonfirmasiPembayaranRequest;
use App\Http\Requests\UpdateKonfirmasiPembayaranRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\FileUploadTrait;
use App\Encryptable;


class KonfirmasiPembayaranController extends Controller {

	/**
	 * Display a listing of konfirmasipembayaran
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $konfirmasipembayaran = KonfirmasiPembayaran::all();


		return view('admin.konfirmasipembayaran.index', compact('konfirmasipembayaran'));
	}

	public function bukti($id)
    {
    	
        $konfirmasipembayaran = KonfirmasiPembayaran::where('pembelian_id',$id)->get();


		return view('admin.konfirmasipembayaran.index', compact('konfirmasipembayaran'));
	}



	/**
	 * Show the form for creating a new konfirmasipembayaran
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    
	   
	 
	 
	}

	public function konfirmasi($id)
	{
	   
	    $pembelian = Pembelian::find($id);
	 
	 	return view('admin.konfirmasipembayaran.create', compact('pembelian'));
	}

	





	/**
	 * Store a newly created konfirmasipembayaran in storage.
	 *
     * @param CreateKonfirmasiPembayaranRequest|Request $request
	 */
	public function store(CreateKonfirmasiPembayaranRequest $request)
	{
		
	    $request = $this->saveFiles($request);
	 	$id = $request->pembelian_id;
	 	$pembelian = Pembelian::find($id);
	 	$kode_konfirmasi = $pembelian->kode_konfirmasi;
	 	
	 	if($kode_konfirmasi == $request['kode_konfirmasi']){

		KonfirmasiPembayaran::create($request->all());
		Pembelian::where('id',$id)->update(['status_konfirmasi' => 1]);
		 
		return redirect()->route('admin.pembelian.index')->with('Berhasil Konfirmasi');

		}
		else
		
		{
			return Redirect::back()->withErrors('Kode Konfirmasi Salah');;
		}	
    
	
	}

	/**
	 * Show the form for editing the specified konfirmasipembayaran.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$pembelian = Pembelian::find($id);
	    
	    
		return view('admin.konfirmasipembayaran.create', compact('pembelian'));
	}

	/**
	 * Update the specified konfirmasipembayaran in storage.
     * @param UpdateKonfirmasiPembayaranRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateKonfirmasiPembayaranRequest $request)
	{
		$konfirmasipembayaran = KonfirmasiPembayaran::findOrFail($id);

        $request = $this->saveFiles($request);

		$konfirmasipembayaran->update($request->all());

		return redirect()->route('admin.konfirmasipembayaran.index');
	}

	/**
	 * Remove the specified konfirmasipembayaran from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		KonfirmasiPembayaran::destroy($id);

		return redirect()->route('admin.konfirmasipembayaran.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            KonfirmasiPembayaran::destroy($toDelete);
        } else {
            KonfirmasiPembayaran::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.konfirmasipembayaran.index');
    }

}
