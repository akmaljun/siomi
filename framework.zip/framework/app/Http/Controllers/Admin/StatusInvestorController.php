<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\StatusInvestor;
use App\Http\Requests\CreateStatusInvestorRequest;
use App\Http\Requests\UpdateStatusInvestorRequest;
use Illuminate\Http\Request;



class StatusInvestorController extends Controller {

	/**
	 * Display a listing of statusinvestor
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $statusinvestor = StatusInvestor::all();

		return view('admin.statusinvestor.index', compact('statusinvestor'));
	}

	/**
	 * Show the form for creating a new statusinvestor
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    
	    
	    return view('admin.statusinvestor.create');
	}

	/**
	 * Store a newly created statusinvestor in storage.
	 *
     * @param CreateStatusInvestorRequest|Request $request
	 */
	public function store(CreateStatusInvestorRequest $request)
	{
	    
		StatusInvestor::create($request->all());

		return redirect()->route('admin.statusinvestor.index');
	}

	/**
	 * Show the form for editing the specified statusinvestor.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$statusinvestor = StatusInvestor::find($id);
	    
	    
		return view('admin.statusinvestor.edit', compact('statusinvestor'));
	}

	/**
	 * Update the specified statusinvestor in storage.
     * @param UpdateStatusInvestorRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateStatusInvestorRequest $request)
	{
		$statusinvestor = StatusInvestor::findOrFail($id);

        

		$statusinvestor->update($request->all());

		return redirect()->route('admin.statusinvestor.index');
	}

	/**
	 * Remove the specified statusinvestor from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		StatusInvestor::destroy($id);

		return redirect()->route('admin.statusinvestor.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            StatusInvestor::destroy($toDelete);
        } else {
            StatusInvestor::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.statusinvestor.index');
    }

}
