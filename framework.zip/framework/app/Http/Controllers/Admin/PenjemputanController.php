<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Penjemputan;
use App\Http\Requests\CreatePenjemputanRequest;
use App\Http\Requests\UpdatePenjemputanRequest;
use Illuminate\Http\Request;
use Auth;



class PenjemputanController extends Controller {

	/**
	 * Display a listing of penjemputan
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {

    
    	if(Auth::user()->role_id == 6){

    		$id = Auth::user()->id;
   			$penjemputan1 = Penjemputan::where('user_id',$id)->first();
   		
    			if($penjemputan1){

    		$penjemputan = Penjemputan::where('user_id',$id)->get();
    	 		return view('admin.penjemputan.index', compact("penjemputan"));
    	
		    	}
    	else {
return view('admin.penjemputan.create');	
}
    	} else {
    		
    	
        $penjemputan = Penjemputan::all();

		return view('admin.penjemputan.index', compact('penjemputan'));
	}
	}

	/**
	 * Show the form for creating a new penjemputan
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    
	    return view('admin.penjemputan.create');
	}

	/**
	 * Store a newly created penjemputan in storage.
	 *
     * @param CreatePenjemputanRequest|Request $request
	 */
	public function store(CreatePenjemputanRequest $request)
	{
	    

		$penjemputan = new Penjemputan();
		$penjemputan->Tempat = $request['Tempat'];
		$penjemputan->Waktu = $request['Waktu'];
		$penjemputan->user_id = $request['user_id'];
		$penjemputan->save();
		return redirect()->route('admin.penjemputan.index');
	}

	/**
	 * Show the form for editing the specified penjemputan.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$penjemputan = Penjemputan::find($id);
		$status = ['1'=>'telah dijemput',null=>'belum dijemput'];
	    
	    
		return view('admin.penjemputan.edit', compact('penjemputan','status'));
	}

	/**
	 * Update the specified penjemputan in storage.
     * @param UpdatePenjemputanRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdatePenjemputanRequest $request)
	{
		$penjemputan = Penjemputan::findOrFail($id);

        

		$penjemputan->update($request->all());

		return redirect()->route('admin.penjemputan.index');
	}

	/**
	 * Remove the specified penjemputan from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Penjemputan::destroy($id);

		return redirect()->route('admin.penjemputan.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Penjemputan::destroy($toDelete);
        } else {
            Penjemputan::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.penjemputan.index');
    }

}
