<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Identitas;
use App\Http\Requests\CreateIdentitasRequest;
use App\Http\Requests\UpdateIdentitasRequest;
use Illuminate\Http\Request;

use App\DataInvestor;


class IdentitasController extends Controller {

	/**
	 * Display a listing of identitas
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $identitas = Identitas::with("datainvestor")->get();

		return view('admin.identitas.index', compact('identitas'));
	}

	/**
	 * Show the form for creating a new identitas
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
	    return view('admin.identitas.create', compact("datainvestor"));
	}

	/**
	 * Store a newly created identitas in storage.
	 *
     * @param CreateIdentitasRequest|Request $request
	 */
	public function store(CreateIdentitasRequest $request)
	{
	    
		Identitas::create($request->all());

		return redirect()->route('admin.identitas.index');
	}

	/**
	 * Show the form for editing the specified identitas.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$identitas = Identitas::find($id);
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.identitas.edit', compact('identitas', "datainvestor"));
	}

	/**
	 * Update the specified identitas in storage.
     * @param UpdateIdentitasRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateIdentitasRequest $request)
	{
		$identitas = Identitas::findOrFail($id);

        

		$identitas->update($request->all());

		return redirect()->route('admin.identitas.index');
	}

	/**
	 * Remove the specified identitas from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Identitas::destroy($id);

		return redirect()->route('admin.identitas.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Identitas::destroy($toDelete);
        } else {
            Identitas::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.identitas.index');
    }

}
