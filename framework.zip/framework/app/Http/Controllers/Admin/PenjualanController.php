<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Penjualan;
use App\Http\Requests\CreatePenjualanRequest;
use App\Http\Requests\UpdatePenjualanRequest;
use Illuminate\Http\Request;

use App\DataInvestor;
use App\Reksadana;
use App\Rekening;
use Auth;
use App\User;
use Mail;
use PDF;
use App;

class PenjualanController extends Controller {

	/**
	 * Display a listing of penjualan
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
    
    
        $penjualan = Penjualan::with("user")->with("reksadana")->with("rekening")->get();

       
       	return view('admin.penjualan.index', compact('penjualan'));
	}

	/**
	 * Show the form for creating a new penjualan
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{	
		$id = Auth::user()->id;
		
	    $datainvestor = User::with("investor")->where('id',$id)->first();	
	   	$investor_id = $datainvestor->investor->id;
	  
		$rekening = Rekening::where('datainvestor_id',$investor_id)->lists("nomor_rekening", "id")->prepend('Please select', '');
		$reksadana = Reksadana::where('datainvestor_id',$investor_id)->lists("nama", "id")->prepend('Please select', '');
	
 	return view('admin.penjualan.create', compact('datainvestor','rekening','reksadana'));
	   			
	}

	/**
	 * Store a newly created penjualan in storage.
	 *
     * @param CreatePenjualanRequest|Request $request
	 */
	public function store(CreatePenjualanRequest $request)
	{
	 $KodeKonfirmasi = str_random(5);
	    
	    $request['KodeKonfirmasi']= $KodeKonfirmasi;   
		
		$id = $request['user_id'];

	    $user = User::findOrFail($id);
	    Penjualan::create($request->all());



	    Mail::send('emails.konfirmasi', ['user' => $user,'kode_konfirmasi'=>$KodeKonfirmasi], function ($m) use ($user) {
       	$m->from('oso@mail.com', 'Operasional Tim');
        $m->to($user->email, $user->name)->subject('Kode Konfirmasi');
        });

		return redirect()->route('admin.penjualan.index');
	}

	
	public function konfirmasi($id)
	{
	   
	    $penjualan = Penjualan::find($id);
	 
	 	return view('admin.penjualan.edit', compact('penjualan'));
	}

	public function validasi($id,Request $request)
	{
		
	 	$penjualan = Penjualan::find($id);
	 	$KodeKonfirmasi = $penjualan->KodeKonfirmasi;
	 	
	 	if($KodeKonfirmasi == $request['KodeKonfirmasi']){

		

		Penjualan::where('id',$id)->update(['status_konfirmasi' => 1]);
		
		$id = Auth::user()->id;
		  $user = User::findOrFail($id);
	    Mail::send('emails.penjualan', ['user' => $user], function ($m) use ($user) {
       	$m->from('oso@mail.com', 'Operasional Tim');
        $m->to($user->email, $user->name)->subject('Status Pencairan');
        });

		 
			return redirect()->route('admin.penjualan.index');

		}
		else
		
		{
			return redirect()->back()->withErrors('Kode Konfirmasi Salah');;
		}	
    
	
	}

		public function cairkan($id)
	{
	
	    Penjualan::where('id',$id)->update(['statusPencairan' => 1]);
	 	$penjualan = Penjualan::find($id);

		 $jumlahrupiah = $penjualan->jumlahrupiah;

	 	$id = Auth::user()->id;
		  $user = User::findOrFail($id);

	 	Mail::send('emails.pencairan', ['user' => $user,'jumlahrupiah'=>$jumlahrupiah], function ($m) use ($user) {
       	$m->from('oso@mail.com', 'Operasional Tim');
        $m->to($user->email, $user->name)->subject('Status Pencairan');
        });

	 			return redirect()->route('admin.penjualan.index');

	}


		public function makepdf($id)
	{	

	return PDF::loadFile(public_path().'/penjualan.html')->stream('download.pdf');

	}
		/**
	 * Show the form for editing the specified penjualan.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$penjualan = Penjualan::find($id);
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');
$reksadana = Reksadana::lists("nama", "id")->prepend('Please select', '');
$rekening = Rekening::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.penjualan.edit', compact('penjualan', "datainvestor", "reksadana", "rekening"));
	}

	/**
	 * Update the specified penjualan in storage.
     * @param UpdatePenjualanRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdatePenjualanRequest $request)
	{
		$penjualan = Penjualan::findOrFail($id);

        

		$penjualan->update($request->all());

		return redirect()->route('admin.penjualan.index');
	}

	/**
	 * Remove the specified penjualan from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Penjualan::destroy($id);

		return redirect()->route('admin.penjualan.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Penjualan::destroy($toDelete);
        } else {
            Penjualan::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.penjualan.index');
    }

}
