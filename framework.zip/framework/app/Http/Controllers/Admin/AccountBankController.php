<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\AccountBank;
use App\Http\Requests\CreateAccountBankRequest;
use App\Http\Requests\UpdateAccountBankRequest;
use Illuminate\Http\Request;

use App\Rekening;


class AccountBankController extends Controller {

	/**
	 * Display a listing of accountbank
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $accountbank = AccountBank::with("rekening")->get();

		return view('admin.accountbank.index', compact('accountbank'));
	}

	/**
	 * Show the form for creating a new accountbank
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $rekening = Rekening::lists("id", "id")->prepend('Please select', '');

	    
	    return view('admin.accountbank.create', compact("rekening"));
	}

	/**
	 * Store a newly created accountbank in storage.
	 *
     * @param CreateAccountBankRequest|Request $request
	 */
	public function store(CreateAccountBankRequest $request)
	{
	    
		AccountBank::create($request->all());

		return redirect()->route('admin.accountbank.index');
	}

	/**
	 * Show the form for editing the specified accountbank.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$accountbank = AccountBank::find($id);
	    $rekening = Rekening::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.accountbank.edit', compact('accountbank', "rekening"));
	}

	/**
	 * Update the specified accountbank in storage.
     * @param UpdateAccountBankRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateAccountBankRequest $request)
	{
		$accountbank = AccountBank::findOrFail($id);

        

		$accountbank->update($request->all());

		return redirect()->route('admin.accountbank.index');
	}

	/**
	 * Remove the specified accountbank from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		AccountBank::destroy($id);

		return redirect()->route('admin.accountbank.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            AccountBank::destroy($toDelete);
        } else {
            AccountBank::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.accountbank.index');
    }

}
