<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Apply;
use App\Http\Requests\CreateApplyRequest;
use App\Http\Requests\UpdateApplyRequest;
use Illuminate\Http\Request;



class ApplyController extends Controller {

	/**
	 * Display a listing of apply
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $apply = Apply::all();

		return view('admin.apply.index', compact('apply'));
	}

	/**
	 * Show the form for creating a new apply
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    
	    
	    return view('admin.apply.create');
	}

	/**
	 * Store a newly created apply in storage.
	 *
     * @param CreateApplyRequest|Request $request
	 */
	public function store(CreateApplyRequest $request)
	{
	    
		Apply::create($request->all());

		return redirect()->route('admin.apply.index');
	}

	/**
	 * Show the form for editing the specified apply.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$apply = Apply::find($id);
	    
	    
		return view('admin.apply.edit', compact('apply'));
	}

	/**
	 * Update the specified apply in storage.
     * @param UpdateApplyRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateApplyRequest $request)
	{
		$apply = Apply::findOrFail($id);

        

		$apply->update($request->all());

		return redirect()->route('admin.apply.index');
	}

	/**
	 * Remove the specified apply from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Apply::destroy($id);

		return redirect()->route('admin.apply.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Apply::destroy($toDelete);
        } else {
            Apply::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.apply.index');
    }

}
