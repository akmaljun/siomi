<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Reksadana;
use App\Http\Requests\CreateReksadanaRequest;
use App\Http\Requests\UpdateReksadanaRequest;
use Illuminate\Http\Request;



class ReksadanaController extends Controller {

	/**
	 * Display a listing of reksadana
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $reksadana = Reksadana::all();

		return view('admin.reksadana.index', compact('reksadana'));
	}

	/**
	 * Show the form for creating a new reksadana
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    
	    
	    return view('admin.reksadana.create');
	}

	/**
	 * Store a newly created reksadana in storage.
	 *
     * @param CreateReksadanaRequest|Request $request
	 */
	public function store(CreateReksadanaRequest $request)
	{
	    
		Reksadana::create($request->all());

		return redirect()->route('admin.reksadana.index');
	}

	/**
	 * Show the form for editing the specified reksadana.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$reksadana = Reksadana::find($id);
	    
	    
		return view('admin.reksadana.edit', compact('reksadana'));
	}

	/**
	 * Update the specified reksadana in storage.
     * @param UpdateReksadanaRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateReksadanaRequest $request)
	{
		$reksadana = Reksadana::findOrFail($id);

        

		$reksadana->update($request->all());

		return redirect()->route('admin.reksadana.index');
	}

	/**
	 * Remove the specified reksadana from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Reksadana::destroy($id);

		return redirect()->route('admin.reksadana.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Reksadana::destroy($toDelete);
        } else {
            Reksadana::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.reksadana.index');
    }

}
