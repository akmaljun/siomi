<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\AlamatInvestor;
use App\Http\Requests\CreateAlamatInvestorRequest;
use App\Http\Requests\UpdateAlamatInvestorRequest;
use Illuminate\Http\Request;

use App\DataInvestor;


class AlamatInvestorController extends Controller {

	/**
	 * Display a listing of alamatinvestor
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $alamatinvestor = AlamatInvestor::with("datainvestor")->get();

		return view('admin.alamatinvestor.index', compact('alamatinvestor'));
	}

	/**
	 * Show the form for creating a new alamatinvestor
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
	    return view('admin.alamatinvestor.create', compact("datainvestor"));
	}

	/**
	 * Store a newly created alamatinvestor in storage.
	 *
     * @param CreateAlamatInvestorRequest|Request $request
	 */
	public function store(CreateAlamatInvestorRequest $request)
	{
	    
		AlamatInvestor::create($request->all());

		return redirect()->route('admin.alamatinvestor.index');
	}

	/**
	 * Show the form for editing the specified alamatinvestor.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$alamatinvestor = AlamatInvestor::find($id);
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.alamatinvestor.edit', compact('alamatinvestor', "datainvestor"));
	}

	/**
	 * Update the specified alamatinvestor in storage.
     * @param UpdateAlamatInvestorRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateAlamatInvestorRequest $request)
	{
		$alamatinvestor = AlamatInvestor::findOrFail($id);

        

		$alamatinvestor->update($request->all());

		return redirect()->route('admin.alamatinvestor.index');
	}

	/**
	 * Remove the specified alamatinvestor from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		AlamatInvestor::destroy($id);

		return redirect()->route('admin.alamatinvestor.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            AlamatInvestor::destroy($toDelete);
        } else {
            AlamatInvestor::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.alamatinvestor.index');
    }

}
