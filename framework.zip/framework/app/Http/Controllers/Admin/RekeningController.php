<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\Rekening;
use App\Http\Requests\CreateRekeningRequest;
use App\Http\Requests\UpdateRekeningRequest;
use Illuminate\Http\Request;

use App\DataInvestor;


class RekeningController extends Controller {

	/**
	 * Display a listing of rekening
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $rekening = Rekening::with("datainvestor")->get();

		return view('admin.rekening.index', compact('rekening'));
	}

	/**
	 * Show the form for creating a new rekening
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
	    return view('admin.rekening.create', compact("datainvestor"));
	}

	/**
	 * Store a newly created rekening in storage.
	 *
     * @param CreateRekeningRequest|Request $request
	 */
	public function store(CreateRekeningRequest $request)
	{
	    
		Rekening::create($request->all());

		return redirect()->route('admin.rekening.index');
	}

	/**
	 * Show the form for editing the specified rekening.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$rekening = Rekening::find($id);
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.rekening.edit', compact('rekening', "datainvestor"));
	}

	/**
	 * Update the specified rekening in storage.
     * @param UpdateRekeningRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateRekeningRequest $request)
	{
		$rekening = Rekening::findOrFail($id);

        

		$rekening->update($request->all());

		return redirect()->route('admin.rekening.index');
	}

	/**
	 * Remove the specified rekening from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		Rekening::destroy($id);

		return redirect()->route('admin.rekening.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            Rekening::destroy($toDelete);
        } else {
            Rekening::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.rekening.index');
    }

}
