<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Redirect;
use Schema;
use App\AlamatKtp;
use App\Http\Requests\CreateAlamatKtpRequest;
use App\Http\Requests\UpdateAlamatKtpRequest;
use Illuminate\Http\Request;

use App\DataInvestor;


class AlamatKtpController extends Controller {

	/**
	 * Display a listing of alamatktp
	 *
     * @param Request $request
     *
     * @return \Illuminate\View\View
	 */
	public function index(Request $request)
    {
        $alamatktp = AlamatKtp::with("datainvestor")->get();

		return view('admin.alamatktp.index', compact('alamatktp'));
	}

	/**
	 * Show the form for creating a new alamatktp
	 *
     * @return \Illuminate\View\View
	 */
	public function create()
	{
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
	    return view('admin.alamatktp.create', compact("datainvestor"));
	}

	/**
	 * Store a newly created alamatktp in storage.
	 *
     * @param CreateAlamatKtpRequest|Request $request
	 */
	public function store(CreateAlamatKtpRequest $request)
	{
	    
		AlamatKtp::create($request->all());

		return redirect()->route('admin.alamatktp.index');
	}

	/**
	 * Show the form for editing the specified alamatktp.
	 *
	 * @param  int  $id
     * @return \Illuminate\View\View
	 */
	public function edit($id)
	{
		$alamatktp = AlamatKtp::find($id);
	    $datainvestor = DataInvestor::lists("id", "id")->prepend('Please select', '');

	    
		return view('admin.alamatktp.edit', compact('alamatktp', "datainvestor"));
	}

	/**
	 * Update the specified alamatktp in storage.
     * @param UpdateAlamatKtpRequest|Request $request
     *
	 * @param  int  $id
	 */
	public function update($id, UpdateAlamatKtpRequest $request)
	{
		$alamatktp = AlamatKtp::findOrFail($id);

        

		$alamatktp->update($request->all());

		return redirect()->route('admin.alamatktp.index');
	}

	/**
	 * Remove the specified alamatktp from storage.
	 *
	 * @param  int  $id
	 */
	public function destroy($id)
	{
		AlamatKtp::destroy($id);

		return redirect()->route('admin.alamatktp.index');
	}

    /**
     * Mass delete function from index page
     * @param Request $request
     *
     * @return mixed
     */
    public function massDelete(Request $request)
    {
        if ($request->get('toDelete') != 'mass') {
            $toDelete = json_decode($request->get('toDelete'));
            AlamatKtp::destroy($toDelete);
        } else {
            AlamatKtp::whereNotNull('id')->delete();
        }

        return redirect()->route('admin.alamatktp.index');
    }

}
