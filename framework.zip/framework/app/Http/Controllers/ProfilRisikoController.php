<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Http\Request;
use DB;

class ProfilRisikoController extends Controller
{
public function index() {
	return view('profilrisiko');
	}
	public function tambahkebutuhan (Request $request) {
		DB::table("profil_risiko")->insertGetId(
			['Perolehan'=>$request->skor, 'HasilProfilRisiko'=>$request->hasil]
		);
	return view('hasilsimulasi');
	}
}
