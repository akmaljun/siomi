<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Investor;
use App\Rekening;
use App\User;
use Illuminate\Support\Facades\Hash;
use Mail;

class DaftarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      
	return view('daftarinvestor');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    	
   	
        Investor::create($request->all());
    
        $investor = Investor::latest()->first();
        $id = $investor['id'];
        $password = str_random(5);
        echo $password;
		$rekening = new Rekening();
		$rekening->datainvestor_id = $id;
		$rekening->nomor_rekening = $request['nomor_rekening'];
		$rekening->jenis_kurs = $request['jenis_kurs'];
		$rekening->nama_pemilik_rekening = $request['nama_pemilik_rekening'];
		$rekening->up = $request['up'];
		$rekening->nama = $request['nama'];
		$rekening->cabang = $request['cabang'];
		$rekening->kode_bank = $request['kode_bank'];
		$rekening->save();
		
		$user = new User();
		$user->role_id = 6;
		$user->name = $request['nama_lengkap'];
		$user->email = $request['email'];
		$user->password = Hash::make($password);
		$user->status_id = 1;
	
		$user->save();
	   
    Mail::send('emails.akun', ['user' => $user,'password'=>$password], function ($m) use ($user) {
        $m->from('oso@mail.com', 'Operasional Tim');
        $m->to($user->email, $user->name)->subject('Akun');
        });
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
