<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Laraveldaily\Quickadmin\Observers\UserActionsObserver;

use Carbon\Carbon; 

use Illuminate\Database\Eloquent\SoftDeletes;

class Penjemputan extends Model {

    use SoftDeletes;

    /**
    * The attributes that should be mutated to dates.
    *
    * @var array
    */
    protected $dates = ['deleted_at'];

    protected $table    = 'penjemputan';
    
    protected $fillable = [
          'Tempat',
          'Waktu',
          'investor_id',
          'status'
    ];
    

    public static function boot()
    {
        parent::boot();

        Penjemputan::observe(new UserActionsObserver);
    }
    
     public function investor()
    {
        return $this->hasOne('App\Investor', 'id');
    }
    
    /**
     * Set attribute to date format
     * @param $input
     */
    public function setWaktuAttribute($input)
    {
        $this->attributes['Waktu'] = Carbon::createFromFormat(config('quickadmin.date_format') . ' ' . config('quickadmin.time_format'), $input)->format('Y-m-d H:i:s');
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getWaktuAttribute($input)
    {
        return Carbon::createFromFormat('Y-m-d H:i:s', $input)->format(config('quickadmin.date_format') . ' ' .config('quickadmin.time_format'));
    }


    
}