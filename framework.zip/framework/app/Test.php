<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Laraveldaily\Quickadmin\Observers\UserActionsObserver;

use Carbon\Carbon; 

use Illuminate\Database\Eloquent\SoftDeletes;

class Test extends Model {

    use SoftDeletes;

    /**
    * The attributes that should be mutated to dates.
    *
    * @var array
    */
    protected $dates = ['deleted_at'];

    protected $table    = 'test';
    
    protected $fillable = ['test'];
    

    public static function boot()
    {
        parent::boot();

        Test::observe(new UserActionsObserver);
    }
    
    
    /**
     * Set attribute to date format
     * @param $input
     */
    public function setTestAttribute($input)
    {
        $this->attributes['test'] = Carbon::createFromFormat(config('quickadmin.date_format'), $input)->format('Y-m-d');
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getTestAttribute($input)
    {
        return Carbon::createFromFormat('Y-m-d', $input)->format(config('quickadmin.date_format'));
    }


    
}