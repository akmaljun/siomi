<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class DataInvestor extends Model
{
    //
    protected $dates = ['deleted_at'];

    protected $table    = 'investors';
    
   protected $fillable = [
          'user_id',
          'nama_lengkap',
          'tempat_lahir',
          'tanggal_lahir',
          'jenis_kelamin',
          'agama',
          'status_pernikahan',
          'nama_suami_istri',
          'nama_ahli_waris',
          'hubungan_ahli_waris',
          'pendidikan',
          'pekerjaan',
          'pendapatan_pertahun',
          'sumber_pendapatan',
          'tujuan_investasi',
          'handphone',
          'telepon',
          'email',
          'status',
          'nama_jalan_ktp',
          'kota_ktp',
          'provinsi_ktp',
          'negara_ktp',
          'kode_pos_ktp',
          'nama_jalan',
          'kota',
          'provinsi',
          'negara',
          'kode_pos',
          'jenis',
          'tanggal_kadaluarsa',
          'nomor'
    ];


     public function setInvestorAttribute($input)
    {
        $this->attributes['tanggal_lahir'] = Carbon::createFromFormat(config('quickadmin.date_format'), $input)->format('Y-m-d');
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getInvestorAttribute($input)
    {
        return Carbon::createFromFormat('Y-m-d', $input)->format(config('quickadmin.date_format'));
    }

}
