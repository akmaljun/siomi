<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Laraveldaily\Quickadmin\Observers\UserActionsObserver;


use Illuminate\Database\Eloquent\SoftDeletes;

class AccountBank extends Model {

    use SoftDeletes;

    /**
    * The attributes that should be mutated to dates.
    *
    * @var array
    */
    protected $dates = ['deleted_at'];

    protected $table    = 'accountbank';
    
    protected $fillable = [
          'rekening_id',
          'nama',
          'cabang',
          'kode_bank'
    ];
    

    public static function boot()
    {
        parent::boot();

        AccountBank::observe(new UserActionsObserver);
    }
    
    public function rekening()
    {
        return $this->hasOne('App\Rekening', 'id', 'rekening_id');
    }


    
    
    
}