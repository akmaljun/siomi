<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Laraveldaily\Quickadmin\Observers\UserActionsObserver;


use Illuminate\Database\Eloquent\SoftDeletes;

class Rekening extends Model {

    use SoftDeletes;

    /**
    * The attributes that should be mutated to dates.
    *
    * @var array
    */
    protected $dates = ['deleted_at'];

    protected $table    = 'rekening';
    
    protected $fillable = [
          'datainvestor_id',
          'nomor_rekening',
          'up',
            'nama',
          'cabang',
          'kode_bank',
          'jenis_kurs',
          'nama_pemilik_rekening',

    ];
    

    public static function boot()
    {
        parent::boot();

        Rekening::observe(new UserActionsObserver);
    }
    
    public function datainvestor()
    {
        return $this->hasOne('App\DataInvestor', 'id', 'datainvestor_id');
    }


    
    
    
}