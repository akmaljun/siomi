<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Laraveldaily\Quickadmin\Observers\UserActionsObserver;


use Illuminate\Database\Eloquent\SoftDeletes;

class Reksadana extends Model {

    use SoftDeletes;

    /**
    * The attributes that should be mutated to dates.
    *
    * @var array
    */
    protected $dates = ['deleted_at'];

    protected $table    = 'reksadana';
    
    protected $fillable = ['nama','datainvestor_id'];
    

    public static function boot()
    {
        parent::boot();

        Reksadana::observe(new UserActionsObserver);
    }
    
     public function datainvestor()
    {
        return $this->hasOne('App\DataInvestor', 'id', 'datainvestor_id');
    }
    
    
}