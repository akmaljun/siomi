<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreateKonfirmasiPembayaranTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Model::unguard();
        Schema::create('konfirmasipembayaran',function(Blueprint $table){
            $table->increments("id");
            $table->string("nomor_rekening");
            $table->string("nama_pemegang_rekening");
            $table->string("nama_bank");
            $table->string("cabang");
            $table->string("bank_penerima");
            $table->string("bukti_pembayaran");
            $table->string("kode_konfirmasi");
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('konfirmasipembayaran');
    }

}