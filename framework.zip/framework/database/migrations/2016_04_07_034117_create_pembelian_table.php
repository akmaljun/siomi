<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreatePembelianTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Model::unguard();
        Schema::create('pembelian',function(Blueprint $table){
            $table->increments("id");
            $table->string("nominal");
            $table->string("terbilang");
            $table->string("jenis_mata_uang");
            $table->string("jenis_penempatan");
            $table->string("status");
            $table->integer("reksadana_id")->references("id")->on("reksadana");
            $table->integer("user_id")->references("id")->on("user");
            $table->integer("konfirmasipembayaran_id")->references("id")->on("konfirmasipembayaran");
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('pembelian');
    }

}