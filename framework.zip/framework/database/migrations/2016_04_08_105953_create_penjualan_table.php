<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreatePenjualanTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Model::unguard();
        Schema::create('penjualan',function(Blueprint $table){
            $table->increments("id");
            $table->string("NamaInvestor");
            $table->integer("datainvestor_id")->references("id")->on("datainvestor");
            $table->integer("reksadana_id")->references("id")->on("reksadana");
            $table->tinyInteger("jumlahunit")->default(0)->nullable();
            $table->tinyInteger("jumlahrupiah")->default(0)->nullable();
            $table->string("Terbilang")->nullable();
            $table->integer("rekening_id")->references("id")->on("rekening")->nullable();
            $table->string("KodeKonfirmasi")->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('penjualan');
    }

}