<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Eloquent\Model;

class CreateInvestorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
           Model::unguard();
        Schema::create('investors', function (Blueprint $table) {
            $table->increments("id");
            $table->string("nama_lengkap");
            $table->string("jenis");
            $table->date("tanggal_kadaluarsa");
            $table->string("nomor");
            $table->string("tempat_lahir");
            $table->date("tanggal_lahir");
            $table->string("jenis_kelamin");
            $table->string("agama");
            $table->string("status_pernikahan");
            $table->string("nama_suami/istri");
            $table->string("nama_ahli_waris")->nullable();
            $table->string("hubungan_ahli_waris")->nullable();
            $table->string("pendidikan");
            $table->string("pekerjaan");
            $table->string("pendapatan_pertahun");
            $table->string("sumber_pendapatan");
            $table->string("tujuan_investasi");
            $table->string("handphone");
            $table->string("telepon");
            $table->string("email");
            $table->string("status");
            $table->string("nama_jalan_ktp");
            $table->string("kota_ktp");
            $table->string("provinsi_ktp");
            $table->string("negara_ktp");
            $table->string("kode_pos_ktp");
            $table->string("nama_jalan");
            $table->string("kota");
            $table->string("provinsi");
            $table->string("negara");
            $table->string("kode_pos");
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('investors');
    }
}
