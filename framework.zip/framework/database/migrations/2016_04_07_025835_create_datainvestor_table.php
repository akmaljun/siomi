<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreateDataInvestorTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Model::unguard();
        Schema::create('datainvestor',function(Blueprint $table){
            $table->increments("id");
            $table->integer("user_id")->references("id")->on("user");
            $table->string("nama_lengkap");
            $table->string("tempat_lahir");
            $table->date("tanggal_lahir");
            $table->string("jenis_kelamin");
            $table->string("agama");
            $table->string("status_pernikahan");
            $table->string("nama_suami/istri");
            $table->string("nama_ahli_waris")->nullable();
            $table->string("hubungan_ahli_waris")->nullable();
            $table->tinyInteger("pendidikan")->default(0);
            $table->tinyInteger("pekerjaan")->default(0);
            $table->tinyInteger("pendapatan_pertahun")->default(0);
            $table->tinyInteger("sumber_pendapatan")->default(0);
            $table->tinyInteger("tujuan_investasi")->default(0);
            $table->string("handphone");
            $table->string("telepon");
            $table->string("email");
            $table->string("status");
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('datainvestor');
    }

}