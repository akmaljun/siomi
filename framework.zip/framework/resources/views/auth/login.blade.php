<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>SIOMI</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/form-elements.css">
        <link rel="stylesheet" href="css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

        <!-- Top menu -->
        
        <nav class="navbar navbar-default navbar-static-top" style="background-color: #ffffff;">
  <div class="container">
     <div class="navbar-header">
      <a class="navbar-brand" href="index.html">
        <img alt="Brand" src="img/logo.png">
      </a>
    
    <ul class="nav navbar-nav">
        <li><a href="http://www.oso-manajemeninvestasi.com">Oso Manajemen Investasi</a></li>
        <li><a href="http://www.oso-manajemeninvestasi.com/?scr=08&selectLanguage=1">Kontak Kami</a></li>
        </ul>
</nav>

        <!-- Top content -->
        
            
           
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <h1><strong>Sistem Informasi Oso Manajemen Investasi</strong></h1>
                            <div class="description">
                                <div id="top_content">
                                    <h4>Sudahkan Anda Berinvestasi Hari Ini?</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8 phone">
                            
                        </div>
                        <div class="col-sm-4 form-box">
                            <div class="form-top">
                                <div class="form-top-left">
                                    <h3>Login</h3>
                                    </div>
                               
                            </div>
                            <div class="form-bottom">
                                <form role="form" action="" method="post" class="registration-form" action="{{ url('login') }}">
                                <input type="hidden"
                               name="_token"
                               value="{{ csrf_token() }}">
                                    <div class="form-group">
                                        <label class="sr-only" for="form-user-name">Email</label>
                                        <input type="email" name="email" value="{{ old('email') }}" placeholder="Username" required="required" class="form-user-name form-control" id="form-first-name">
                                    </div>
                                    <div class="form-group">
                                        <label class="sr-only" for="form-password">Password</label>
                                        <input type="password" name="password" placeholder="Password" required="required" class="form-password form-control" id="form-password">
                                    </div>

                                       <div class="form-group">
                        
                                <label>
                                    <input type="checkbox"
                                           name="remember">{{ trans('quickadmin::auth.login-remember_me') }}
                                </label>
                           
                        </div>


                                   
                      
                                <button type="submit"
                                        class="btn btn-success" role="button">
                                    {{ trans('quickadmin::auth.login-btnlogin') }}
                                </button>
                           
                               

                                    <a href="kebutuhan" class="btn btn-info" role="button">Simulasi</a>
                             
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
          
            
        


        <!-- Javascript -->
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="js/jquery.backstretch.min.js"></script>
        <script src="js/retina-1.1.0.min.js"></script>
        <script src="js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>