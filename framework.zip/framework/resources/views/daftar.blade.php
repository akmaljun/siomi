
<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1>DAFTAR</h1>

        @if ($errors->any())
        	<div class="alert alert-danger">
        	    <ul>
                    {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
                </ul>
        	</div>
        @endif
    </div>
</div>

{!! Form::open(array('route' => 'admin.datainvestor.store', 'id' => 'form-with-validation', 'class' => 'form-horizontal')) !!}

<div class="form-group">
    {!! Form::label('nama_lengkap', 'Nama Lengkap*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_lengkap', old('nama_lengkap'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kewarganegaraan', 'Kewarganegaraan*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kewarganegaraan', old('kewarganegaraan'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('jenis', 'No Kartu Identitas', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::hidden('jenis','') !!}
        {!! Form::checkbox('jenis', 'KTP', false) !!}
    <div>
        {!! Form::label('jenis', 'KTP :') !!}
         {!! Form::text('nomor', old('nomor'), array('class'=>'form-control')) !!}

         {!! Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')) !!}
          {!! Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')) !!}


        {!! Form::checkbox('jenis', 'NPWP', false) !!}
        {!! Form::label('jenis', 'NPWP :') !!}
         {!! Form::text('nomor', old('nomor'), array('class'=>'form-control')) !!}
          {!! Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')) !!}
          {!! Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')) !!}


        {!! Form::checkbox('jenis', 'KITAS', false) !!}
        {!! Form::label('jenis', 'KITAS :') !!}
         {!! Form::text('nomor', old('nomor'), array('class'=>'form-control')) !!}
          {!! Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')) !!}
          {!! Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')) !!}


        {!! Form::checkbox('jenis', 'Paspor', false) !!}
        {!! Form::label('jenis', 'Paspor :') !!}
         {!! Form::text('nomor', old('nomor'), array('class'=>'form-control')) !!}
          {!! Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')) !!}
          {!! Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')) !!}


        
    </div>
</div><div class="form-group">
    {!! Form::label('tempat_lahir', 'Tempat Lahir*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('tempat_lahir', old('tempat_lahir'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('tanggal_lahir', 'Tanggal Lahir*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('tanggal_lahir', old('tanggal_lahir'), array('class'=>'form-control datepicker')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('jenis_kelamin', 'Jenis Kelamin*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('jenis_kelamin', old('jenis_kelamin'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('agama', 'Agama*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('agama', old('agama'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('status_pernikahan', 'Status Pernikahan*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('status_pernikahan', old('status_pernikahan'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_suami/istri', 'Nama Suami/Istri*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_suami/istri', old('nama_suami/istri'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_ahli_waris', 'Nama Ahli Waris', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_ahli_waris', old('nama_ahli_waris'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('hubungan_ahli_waris', 'Hubungan dengan Ahli Waris', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('hubungan_ahli_waris', old('hubungan_ahli_waris'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('pendidikan', 'Pendidikan Terakhir*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::hidden('pendidikan','') !!}
        {!! Form::checkbox('pendidikan', 'SD', false) !!}
         {!! Form::label('pendidikan', 'SD') !!}
        {!! Form::checkbox('pendidikan', 'SMA', false) !!}
         {!! Form::label('pendidikan', 'SMA') !!}
        {!! Form::checkbox('pendidikan', 'D3', false) !!}
         {!! Form::label('pendidikan', 'D3') !!}
        </div> 
    <div class="col-sm-10">
        {!! Form::checkbox('pendidikan', 'S1', false) !!}
         {!! Form::label('pendidikan', 'S1') !!}
        {!! Form::checkbox('pendidikan', 'S2', false) !!}
         {!! Form::label('pendidikan', 'S2') !!}
        {!! Form::checkbox('pendidikan', 'S3', false) !!}
         {!! Form::label('pendidikan', 'S3') !!}
        {!! Form::checkbox('pendidikan', 'Lainnya', false) !!}
         {!! Form::label('pendidikan', 'Lainnya') !!}
    </div>
</div><div class="form-group">
    {!! Form::label('pekerjaan', 'Pekerjaan*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::hidden('pekerjaan','') !!}
        {!! Form::checkbox('pekerjaan', 'Karyawan Biasa', false) !!}
         {!! Form::label('pekerjaan', 'Karyawan Biasa') !!}

        {!! Form::checkbox('pekerjaan', 'Ibu Rumah Tangga', false) !!}
         {!! Form::label('pendidikan', 'Ibu Rumah Tangga') !!}

        {!! Form::checkbox('pekerjaan', 'Pegawai Negri Sipil', false) !!}
         {!! Form::label('pendidikan', 'Pegawai Negri Sipil') !!}

        {!! Form::checkbox('pekerjaan', 'Pensiunan', false) !!}
         {!! Form::label('pendidikan', 'Pensiunan') !!}

        {!! Form::checkbox('pekerjaan', 'Pelajar/Mahasiswa', false) !!}
         {!! Form::label('pendidikan', 'Pelajar/Mahasiswa') !!}

        {!! Form::checkbox('pekerjaan', 'TNI', false) !!}
         {!! Form::label('pendidikan', 'TNI') !!}

        {!! Form::checkbox('pekerjaan', 'Wiraswasta', false) !!}
         {!! Form::label('pendidikan', 'Wiraswasta') !!}

        {!! Form::checkbox('pekerjaan', 'Polisi', false) !!}
         {!! Form::label('pendidikan', 'Polisi') !!}

         {!! Form::checkbox('pekerjaan', 'Lainnya', false) !!}
         {!! Form::label('pendidikan', 'Lainnya') !!}

    </div>
</div><div class="form-group">
    {!! Form::label('pendapatan_pertahun', 'Pendapatan Pertahun*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::hidden('pendapatan_pertahun','') !!}
              {!! Form::checkbox('pendapatan_pertahun', '<= IDR 10.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '<= IDR 10.000.000') !!}

        {!! Form::checkbox('pendapatan_pertahun', '> IDR 10.000.000 - 50.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '> IDR 10.000.000 - 50.000.000') !!}

        {!! Form::checkbox('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000') !!}

        {!! Form::checkbox('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000') !!}

        {!! Form::checkbox('pendapatan_pertahun', '>IDR 100.000.000 - 500.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '>IDR 100.000.000 - 500.000.000') !!}

        {!! Form::checkbox('pendapatan_pertahun', '>IDR 500.000.000 - 1.000.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '>IDR 500.000.000 - 1.000.000.000') !!}

        {!! Form::checkbox('pendapatan_pertahun', '> IDR 1.000.000', false) !!}
         {!! Form::label('pendapatan_pertahun', '> IDR 1.000.000') !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('sumber_pendapatan', 'Sumber Pendapatan*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::hidden('sumber_pendapatan','') !!}
        
        {!! Form::checkbox('sumber_pendapatan', 'gaji', false) !!}
        {!! Form::label('sumber_pendapatan', 'Gaji') !!}

        {!! Form::checkbox('sumber_pendapatan', 'keuntungan usaha', false) !!}
        {!! Form::label('sumber_pendapatan', 'Keuntungan Usaha') !!}

        {!! Form::checkbox('sumber_pendapatan', 'lainnya', false) !!}
        {!! Form::label('sumber_pendapatan', 'Lainnya') !!}
    
    </div>
</div><div class="form-group">
    {!! Form::label('nama_jalan', 'Alamat sesuai KTP*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_jalan', old('nama_jalan'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kota', 'Kota*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kota', old('kota'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('provinsi', 'Provinsi*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('provinsi', old('provinsi'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kode_pos', 'Kode Pos*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_pos', old('kode_pos'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('negara', 'Negara*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('negara', old('negara'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_jalan', 'Alamat Koresponden*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_jalan', old('nama_jalan'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kota', 'Kota*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kota', old('kota'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('provinsi', 'Provinsi*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('provinsi', old('provinsi'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kode_pos', 'Kode Pos*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_pos', old('kode_pos'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('negara', 'Negara*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('negara', old('negara'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('handphone', 'Handphone*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('handphone', old('handphone'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('telepon', 'Telepon*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('telepon', old('telepon'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('email', 'Email*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::email('email', old('email'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('tujuan_investasi', 'Tujuan Investasi*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::hidden('tujuan_investasi','') !!}
        {!! Form::checkbox('tujuan_investasi','Investasi', false) !!}
         {!! Form::label('sumber_pendapatan', 'Investasi') !!}

        {!! Form::checkbox('tujuan_investasi','Penghasilan', false) !!}
         {!! Form::label('sumber_pendapatan', 'Penghasilan') !!}

        {!! Form::checkbox('tujuan_investasi','Kenaikan Harga', false) !!}
         {!! Form::label('sumber_pendapatan', 'Kenaikan Harga') !!}

        {!! Form::checkbox('tujuan_investasi','Lainnya', false) !!}
         {!! Form::label('sumber_pendapatan', 'Lainnya	') !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('datainvestor_id', 'Investor_id*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="form-group">
    {!! Form::label('nama_pemilik_rekening', 'Nama Pemilik Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama', 'Nama*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama', old('nama'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('cabang', old('cabang'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kurs_rekening', 'Kurs Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kurs_rekening', old('kurs_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kode_bank', 'Kode Bank*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_bank', old('kode_bank'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_pemilik_rekening', 'Nama Pemilik Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('rekening_id', 'rekening_id*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="form-group">
    {!! Form::label('nama', 'Nama*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama', old('nama'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('cabang', old('cabang'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kurs_rekening', 'Kurs Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kurs_rekening', old('kurs_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kode_bank', 'Kode Bank*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_bank', old('kode_bank'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_pemilik_rekening', 'Nama Pemilik Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama', 'Nama*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama', old('nama'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('cabang', old('cabang'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kurs_rekening', 'Kurs Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kurs_rekening', old('kurs_rekening'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kode_bank', 'Kode Bank*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_bank', old('kode_bank'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('status', 'Status*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('status', old('status'), array('class'=>'form-control')) !!}
        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      {!! Form::submit( trans('quickadmin::templates.templates-view_create-create') , array('class' => 'btn btn-primary')) !!}
    </div>
</div>

{!! Form::close() !!}

