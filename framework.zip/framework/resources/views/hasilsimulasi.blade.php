<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>SIOMI</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/form-elements.css">
        <link rel="stylesheet" href="css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

  

    <!-- Top menu -->
     <nav class="navbar navbar-default navbar-static-top" style="background-color: #ffffff;">
  <div class="container">
     <div class="navbar-header">
      <a class="navbar-brand" href="index.html">
        <img alt="Brand" src="img/logo.png">
      </a>
    
    <ul class="nav navbar-nav">
        <li><a href="http://www.oso-manajemeninvestasi.com">Oso Manajemen Investasi</a></li>
        <li><a href="http://www.oso-manajemeninvestasi.com/?scr=08&selectLanguage=1">Kontak Kami</a></li>
        </ul>
</nav>

        <!-- Top content -->
        <div class="top-content">
          
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                       
                        <div class="col-sm-12 form-box">
                          <div class="form-top">
                            <div class="form-top-left">
                              <h3>Hasil Simulasi</h3>
                                <p></p>
                            </div>
                            <div class="form-top-right">
                              <i class="fa fa-money"></i>
                            </div>
                            </div>
                            <div class="form-bottom">
                          <form role="form" action="" method="post" class="registration-form">
                                                              
                <div class="container">
                  <div class="row">
                    <div class="col-sm-4">
                    <h3>RENCANA INVESTASI</h3>
                    <p>Lama hasil investasi</p>
                    <p>Lama hasil investasi</p>
                    <p>Investasi per bulan</p>
                  </div>
                  <div class="col-sm-4">
                    <h3>PRODUK INVESTASI</h3>
                    <p>Anda mengetahui mekanisme kerja Reksa Dana, jenis-jenis produk Reksa Dana yang ada, serta mempunyai pengalaman dalam berinvestasi</p>
                    
                  </div>

                  <div class="col-sm-4">
                      <h3>PILIH PRODUK REKSA DANA</h3>
                      <div class="btn-group">
                                    
                    <select>
                       <option value = "" disabled selected>--pilih--</option>
                      <option value="syariah">OSO Syariah Equity Fund</option>
                      <option value="sustainability">OSO Sustainability Fund</option>
                      <option value="borneo">OSO Borneo Equity Fund</option>
                    </select>
                    </div>
                  </div>
                </div>
              </div>
                  <a class="btn btn-success" type="button" href="daftar">Buat akun</a>
                    
                  
                          </form>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>


        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/retina-1.1.0.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>