<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        <title>SIOMI</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/form-elements.css">
        <link rel="stylesheet" href="css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

		<!-- Top menu -->
		 <nav class="navbar navbar-default navbar-static-top" style="background-color: #ffffff;">
  <div class="container">
     <div class="navbar-header">
      <a class="navbar-brand" href="index.html">
        <img alt="Brand" src="img/logo.png" width="40px" height= 23px" ">
      </a>
    
    <ul class="nav navbar-nav">
        <li><a href="http://www.oso-manajemeninvestasi.com">Oso Manajemen Investasi</a></li>
        <li><a href="http://www.oso-manajemeninvestasi.com/?scr=08&selectLanguage=1">Kontak Kami</a></li>
        </ul>
</nav>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 text">
                            <h1><strong>Simulasi Konsultasi</strong></h1>
                            <div class="description">
                            	<p>
	                            	Investasi Demi Masa Depan Cemerlang!
                            	</p>
                            </div>
                            </div>
                        <div class="col-sm-6 form-box">
                        	<div class="form-top">
                        		<div class="form-top-left">
                        			<h3>Simulasi</h3>
                            		<p>Silakan isi formulir di bawah ini:</p>
                        		</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-money"></i>
                        		</div>
                            </div>
                            <div class="form-bottom">
			                    <form role="form" action="kebutuhan" method="post" class="registration-form" >
                            
			                    	<div class="form-group">
			                    		<label class="sr-only" for="form-kebutuhan">Kebutuhan yang diinginkan :</label>
                                         
			                        	<select name="jeniskebutuhan" id="sel_kbth" required="required">
                                         <option value = "" disabled selected>--pilih--</option>
                                         <option value = "pendidikan">Pendidikan</option>
                                         <option value = "mobil">Mobil</option>
                                         <option value = "tempattinggal">Tempat Tinggal</option>
                                         <option value = "liburan">Liburan</option>
                                         <option value = "umum">Umum</option>
                                     </select>

			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="form-last-name">Target hasil investasi :</label>
			                        	<input type="text" name="target" placeholder="Target hasil investasi"  required="required" class="form-last-name form-control" id="form-target">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="form-email">Lama waktu investasi :</label>
			                        	<input type="text" name="waktu" placeholder="Lama waktu" required="required" class="form-email form-control" id="form-waktu">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="form-about-yourself">Investasi per bulan :</label>
			                        	<input type="text" name="investasi" placeholder="Investasi per bulan" required="required" 
			                        				class="form-about-yourself form-control" id="form-investasi">
			                        </div>
			                        <button class="btn btn-success" type="submit" role="button" align="right">Selanjutnya</button>
			                    {!! csrf_field() !!}
                                </form>

		                    </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>


        <!-- Javascript -->
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="js/jquery.backstretch.min.js"></script>
        <script src="js/retina-1.1.0.min.js"></script>
        <script src="js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>