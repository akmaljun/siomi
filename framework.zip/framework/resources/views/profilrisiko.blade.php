<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>SIOMI</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/form-elements.css">
        <link rel="stylesheet" href="css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

		<!-- Top menu -->
		 <nav class="navbar navbar-default navbar-static-top" style="background-color: #ffffff;">
  <div class="container">
     <div class="navbar-header">
      <a class="navbar-brand" href="index.html">
        <img alt="Brand" src="img/logo.png">
      </a>
    
    <ul class="nav navbar-nav">
        <li><a href="http://www.oso-manajemeninvestasi.com">Oso Manajemen Investasi</a></li>
        <li><a href="http://www.oso-manajemeninvestasi.com/?scr=08&selectLanguage=1">Kontak Kami</a></li>
        </ul>
</nav>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                       
                        <div class="col-sm-12 form-box">
                        	<div class="form-top">
                        		<div class="form-top-left">
                        			<h3>Simulasi</h3>
                            		<p>Silakan isi formulir di bawah ini:</p>
                        		</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-money"></i>
                        		</div>
                            </div>
                            <div class="form-bottom">
			                   <form role="form" action="" method="post" class="registration-form">
                                    <div class="form-group">
                                        <p>A. TUJUAN INVESTASI DI REKSA DANA</p>
                                        <p>1. Apakah tujuan anda berinvestasi di Reksa Dana</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio1">Pendapatan dan pertumbuhan dana jangka panjang</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio1">Pendapatan dan keamanan dana investasi</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio1">Keamanan modal atau investasi</label>
                                        </div>
                                   <div class="form-group">
                                        <p>2. Menurut Anda yang paling sesuai dengan tujuan investasi Anda tersebut adalah investasi pada:</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio2">Saham</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio2">Obligasi, pasar uang dan atau kombinasi saham</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio2">Instrumen pasar uang</label>
                                        </div>
                                    </div>
                                     <div class="form-group">
                                        <p>3. Menurut Anda komposisi yang paling sesuai dengan tujuan investasi Anda adalah :</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio3">Kombinasi antara 80% saham dan 20% pasar uang</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio3">Kombinasi antara 80% obligasi dan 20% pasar uang</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio3">100% pasar uang</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <p>B. PORSI DANA INVESTASI REKSA DANA TERHADAP ASET</p>
                                        <p>4. Jumlah dana investasi pada Reksa Dana ini merupakan:</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio4">Kurang dari 35% dari seluruh aset yang saya miliki </label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio4">Antara 35% sampai 70% dari aset yang saya miliki</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio4">Lebih dari 70% dari aset yang saya miliki</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <p>C. TINGKAT RISIKO YANG SANGGUP DITANGGUNG</p>
                                        <p>5.  Pernyataan mana yang paling menggambarkan diri Anda dalam hal risiko investasi:</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio5">Kurang dari 35% dari seluruh aset yang saya miliki </label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio5">Antara 35% sampai 70% dari aset yang saya miliki</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio5">Lebih dari 70% dari aset yang saya miliki</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <p>6. Apabila terjadi kerugian pada investasi Reksa Dana Anda, dampak resiko pada keuangan dan kekayaan Anda: :</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio6">Normal, karena saya sudah perhitungkan risiko tersebut</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio6">Berpengaruh, karena investasi tersebut merupakan sebagian penghasilan saya</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio6">Sangat berpengaruh, karena penghasilan saya sangat tergantung terhadap return Reksa Dana</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <p>D. KEPENTINGAN ATAS POKOK INVESTASI</p>
                                        <p>7. Bagaimana pandangan Anda mengenai kemungkinan Anda kehilangan sebagian dari dari pokok investasi Anda?</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio7">Saya tidak menginginkan kerugian apapun dari investasi saya, karena akan dapat menganggu pendapatan rutin saya</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio7">Saya masih dapat menerima sedikit kerugian sebagai dampak dari fluktuasi investasi saya, karena saya melakukan investasi untuk jangka panjang</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio7">Saya dapat menerima kemungkinan mengalami kerugian dari investasi, karena saya sudah menyediakan dana cadangan untuk kebutuhan rutin saya</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <p>E. JANGKA WAKTU INVESTASI</p>
                                        <p>8. Berapa lama Anda berencana menginvestasikan dana Anda?</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio8">Kurang dari 1 tahun</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio8">1 - 5 tahun</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio8"> > 5 tahun</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <p>F. TINGKAT PENGETAHUAN PEMODAL REKSA DANA</p>
                                        <p>9. Tingkat pengetahuan Anda tentang Reksa Dana secara umum:</p>
                                        <div class="radio">
                                            <label><input value="3" type="radio" name="optradio9">Anda mengetahui mekanisme kerja Reksa Dana, jenis-jenis produk Reksa Dana yang ada, serta mempunyai pengalaman dalam berinvestasi</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="2" type="radio" name="optradio9">Anda cukup mengetahui mekanisme kerja Reksa Dana dengan baik dan mengetahui perbedaan dari masing-masing jenis Reksa Dana</label>
                                        </div>
                                        <div class="radio">
                                            <label><input value="1" type="radio" name="optradio9">Anda mengetahui namun hanya terbatas bahwa Reksa Dana berbeda dengan deposito berjangka, dan didalamnya mengandung risiko atas hasil investasi negatif</label>
                                        </div>
                                    </div>
                                    <a href="hasilsimulasi" class="btn btn-success" role="button">Simulasi</a>
                                {!! csrf_field() !!}
                                </form>
		                    </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>


        <!-- Javascript -->
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="js/jquery.backstretch.min.js"></script>
        <script src="js/retina-1.1.0.min.js"></script>
        <script src="js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>