@extends('admin.layouts.master')

@section('content')

@if(Auth::user()->  role_id == 2)
<p>{!! link_to_route('admin.penjualan.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')) !!}</p>
@endif

@if ($penjualan->count())
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption">{{ trans('quickadmin::templates.templates-view_index-list') }}</div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable">
                <thead>
                    <tr>
                    
                        <th>Nama Investor</th>
<th>Nomor Investor</th>
<th>Nama Reksadana</th>
<th>Jumlah Rupiah</th>
<th>Terbilang</th>
<th>Nomor Rekening</th>
@if(Auth::user()->role_id == 2 || Auth::user()->role_id == 3 || Auth::user()->role_id == 4)
<th>Status Konfirmasi</th>
<th></th>

@if(Auth::user()->role_id == 2)
<th></th>
@endif



@endif

                       
                    </tr>
                </thead>

                <tbody>
                    @foreach ($penjualan as $row)
                        <tr>
                          
                            <td>{{ $row->NamaInvestor }}</td>
<td>{{ isset($row->user->id) ? $row->user->id : '' }}</td>
<td>{{ isset($row->reksadana->nama) ? $row->reksadana->nama: '' }}</td>

<td>{{ $row->jumlahrupiah }}</td>
<td>{{ $row->Terbilang }}</td>
<td>{{ isset($row->rekening->nomor_rekening) ? $row->rekening->nomor_rekening : '' }}</td>

@if(Auth::user()->role_id == 2)

<td>{{ isset($row->status_konfirmasi)? 'Telah dikonfirmasi' :  link_to_route('admin.penjualan.konfirmasi','Konfirmasi',array($row->id), array('class' => 'btn btn-xs btn-info')) }}</td>
    @if($row->status_konfirmasi)
<td>{{ isset($row->statusPencairan)? 'Telah Dicairkan' :  'Menunggu Pencairan' }}</td>
 @if($row->statusPencairan)
    <td>{!! link_to_route('admin.penjualan.pdf','LIHAT', array($row->id), array('class' => 'btn btn-xs btn-info')) !!}</td>
 @else
 <td></td>
 @endif
@else
<td></td>
@endif
@endif

@if(Auth::user()->role_id == 3)
<td>{{ isset($row->status_konfirmasi)? 'Telah Dikonfirmasi' :  'Belum Dikonfirmasi' }}</td>
<td>{{ isset($row->statusPencairan)? 'Telah dicairkan' :  'Menunggu Pencairan' }}</td>
@endif


@if(Auth::user()->role_id == 4)
<td>{{ isset($row->status_konfirmasi)? 'Telah Dikonfirmasi' :  'Belum Dikonfirmasi' }}</td>
@if($row->status_konfirmasi)
<td>{{ isset($row->statusPencairan)? 'Telah dicairkan' :  link_to_route('admin.penjualan.cairkan','Cairkan',array($row->id), array('class' => 'btn btn-xs btn-info')) }}</td>
@else
<td></td>
@endif
@endif


                        </tr>
                    @endforeach
                </tbody>
            </table>
            
           
        </div>
	</div>
@else
    {{ trans('quickadmin::templates.templates-view_index-no_entries_found') }}
@endif

@endsection

