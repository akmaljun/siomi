@extends('admin.layouts.master')

@section('content')

<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1>{{ trans('quickadmin::templates.templates-view_create-add_new') }}</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
                </ul>
            </div>
        @endif
    </div>
</div>

{!! Form::open(array('route' => 'admin.penjualan.store', 'id' => 'form-with-validation', 'class' => 'form-horizontal')) !!}

<div class="form-group hidden ">
    {!! Form::label('NamaInvestor', 'Nama Investor*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('NamaInvestor',$datainvestor->investor->nama_lengkap, old('NamaInvestor'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('datainvestor_id', 'Nomor Investor*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('datainvestor_id', $datainvestor->id, old('datainvestor_id'), array('class'=>'form-control')) !!}
        
    </div>
</div>


    <div class="form-group">
    {!! Form::label('reksadana_id', 'Nama Reksadana*', array('class'=>'col-sm-2 control-label')) !!}

    <div class="col-sm-10">

        {!! Form::select('reksadana_id', $reksadana, old('reksadana_id'), array('class'=>'form-control')) !!}

    </div>
</div>

<div class="form-group">
    {!! Form::label('jumlahrupiah', 'Jumlah Rupiah', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('jumlahrupiah', old('Jumlah Rupiah'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('Terbilang', 'Terbilang', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('Terbilang', old('Terbilang'), array('class'=>'form-control')) !!}
        
    </div>
</div>

<div class="form-group">
    {!! Form::label('rekening_id', 'Nomor Rekening', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">

        {!! Form::select('rekening_id', $rekening, old('rekening_id'), array('class'=>'form-control')) !!}

    </div>
</div>

<div class="form-group hidden">
    {!! Form::label('user_id', 'user_id', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">

        {!! Form::text('user_id', Auth::user()->id, old('user_id'), array('class'=>'form-control')) !!}

    </div>
</div>

<div class="form-group hidden">
    {!! Form::label('KodeKonfirmasi', 'KodeKonfirmasi', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('KodeKonfirmasi', old('KodeKonfirmasi'), array('class'=>'form-control')) !!}
        
    </div>
</div>



<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      {!! Form::submit( trans('quickadmin::templates.templates-view_create-create') , array('class' => 'btn btn-primary')) !!}
    </div>
</div>

{!! Form::close() !!}

@endsection