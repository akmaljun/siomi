@extends('admin.layouts.master')

@section('content')

<!--p>{!! link_to_route('admin.news.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')) !!}</p-->

@if ($news->count())
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption">{{ trans('quickadmin::templates.templates-view_index-list') }}
			</div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable" border="0.5">                
                    @foreach ($news as $row)
                        <!--tr>
							<th style='text-align:center; vertical-align:middle' rowspan="5"></th>
						</tr-->						
						<tr>
							<th>Judul</th>
							<td>{{ $row->Judul }}</td>
						</tr>
						<tr>
							<th>Deskripsi</th>
							<td><textarea rows="5" cols="100%">{{ $row->Isi }}</textarea></td>
						</tr>
						<tr hidden>
							<th>Pembuatan News</th>
							<td>{{ date('d F Y, H:i:s', strtotime($row->created_at)) }}</td>
						</tr>
						<tr hidden>
							<th>Perubahan News</th>
							<td>{{ date('d F Y, H:i:s', strtotime($row->updated_at)) }}</td>
						</tr>
						<tr>
							<th colspan="2"></th>
						</tr>
					@endforeach                
            </table></br>
			<div style='text-align:right; vertical-align:right'>
				{!! link_to_route('admin.news.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')) !!}
				{!! link_to_route('admin.news.edit', trans('quickadmin::templates.templates-view_index-edit'), array($row->id), array('class' => 'btn btn-success')) !!}
				<!--{!! Form::open(array('style' => 'display: inline-block;', 'method' => 'DELETE', 'onsubmit' => "return confirm('".trans("quickadmin::templates.templates-view_index-are_you_sure")."');",  'route' => array('admin.news.destroy', $row->id))) !!}
                {!! Form::submit(trans('quickadmin::templates.templates-view_index-delete'), array('class' => 'btn btn-xs btn-danger')) !!}
				{!! Form::close() !!}-->
			</div>
            {!! Form::close() !!}
        </div>
	</div>
@else
    {{ trans('quickadmin::templates.templates-view_index-no_entries_found') }}
@endif
@endsection