@extends('admin.layouts.master')

@section('content')

<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1>{{ trans('quickadmin::templates.templates-view_edit-edit') }}</h1>

        @if ($errors->any())
        	<div class="alert alert-danger">
        	    <ul>
                    {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
                </ul>
        	</div>
        @endif
    </div>
</div>

{!! Form::model($konfirmasipembayaran, array('files' => true, 'class' => 'form-horizontal', 'id' => 'form-with-validation', 'method' => 'PATCH', 'route' => array('admin.konfirmasipembayaran.update', $konfirmasipembayaran->id))) !!}

<div class="form-group">
    {!! Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nomor_rekening', old('nomor_rekening',$konfirmasipembayaran->nomor_rekening), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_pemegang_rekening', 'Nama Pemegang Rekening*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_pemegang_rekening', old('nama_pemegang_rekening',$konfirmasipembayaran->nama_pemegang_rekening), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('nama_bank', 'Nama Bank*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nama_bank', old('nama_bank',$konfirmasipembayaran->nama_bank), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('cabang', old('cabang',$konfirmasipembayaran->cabang), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('bank_penerima', 'Bank Penerima*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('bank_penerima', old('bank_penerima',$konfirmasipembayaran->bank_penerima), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('bukti_pembayaran', 'Bukti Pembayaran', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::file('bukti_pembayaran') !!}
        {!! Form::hidden('bukti_pembayaran_w', 4096) !!}
        {!! Form::hidden('bukti_pembayaran_h', 4096) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('kode_konfirmasi', 'Kode Konfirmasi*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_konfirmasi', old('kode_konfirmasi',$konfirmasipembayaran->kode_konfirmasi), array('class'=>'form-control')) !!}
        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      {!! Form::submit(trans('quickadmin::templates.templates-view_edit-update'), array('class' => 'btn btn-primary')) !!}
      {!! link_to_route('admin.konfirmasipembayaran.index', trans('quickadmin::templates.templates-view_edit-cancel'), null, array('class' => 'btn btn-default')) !!}
    </div>
</div>

{!! Form::close() !!}

@endsection