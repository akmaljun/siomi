@extends('admin.layouts.master')

@section('content')



@if ($konfirmasipembayaran->count())

    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption">Konfirmasi Pembayaran</div>
        </div>
        <div class="portlet-body">
         @foreach ($konfirmasipembayaran as $row)
              <div class="col-sm-10">
                <h1>Nomor Rekening :{{ $row->nomor_rekening }}</h1>
             </div>
             <div class="col-sm-10">
              <h1>Nama Pemegang Rekening :{{ $row->nama_pemegang_rekening }}</h1>
              </div>
               <div class="col-sm-10">
              <h1>Nama Bank :{{ $row->nama_bank }}</h1>
            </div>
               <div class="col-sm-10">
             <h1>Cabang : {{ $row->cabang }} </h1>
             </div>
              <div class="col-sm-10">
             <h1>Bank Penerima : {{ $row->bank_penerima }} </h1>
             </div>
             <div class ="col-sm-10">
             <h1>Bukti Pembayaran : @if($row->bukti_pembayaran != '')<img src="{{ asset('uploads/thumb') . '/'.  $row->bukti_pembayaran }}">@endif </h1>
            </div>
                    @endforeach
                </tbody>
            </table>
            <div class="row">
                <div class="col-xs-12">
                   
                </div>
            </div>
           
        </div>
	</div>
@else
    {{ trans('quickadmin::templates.templates-view_index-no_entries_found') }}
@endif

@endsection

@section('javascript')
    <script>
        $(document).ready(function () {
            $('#delete').click(function () {
                if (window.confirm('{{ trans('quickadmin::templates.templates-view_index-are_you_sure') }}')) {
                    var send = $('#send');
                    var mass = $('.mass').is(":checked");
                    if (mass == true) {
                        send.val('mass');
                    } else {
                        var toDelete = [];
                        $('.single').each(function () {
                            if ($(this).is(":checked")) {
                                toDelete.push($(this).data('id'));
                            }
                        });
                        send.val(JSON.stringify(toDelete));
                    }
                    $('#massDelete').submit();
                }
            });
        });
    </script>
@stop