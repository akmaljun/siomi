@extends('admin.layouts.master')

@section('content')

<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1>{{ trans('quickadmin::templates.templates-view_edit-edit') }}</h1>

        @if ($errors->any())
        	<div class="alert alert-danger">
        	    <ul>
                    {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
                </ul>
        	</div>
        @endif
    </div>
</div>

{!! Form::model($pembelian, array('class' => 'form-horizontal', 'id' => 'form-with-validation', 'method' => 'PATCH', 'route' => array('admin.pembelian.update', $pembelian->id))) !!}

<div class="form-group hidden">
    {!! Form::label('nominal', 'Nominal*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nominal', old('nominal',$pembelian->nominal), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('terbilang', 'Terbilang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('terbilang', old('terbilang',$pembelian->terbilang), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('jenis_mata_uang', 'Jenis Mata Uang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('jenis_mata_uang', old('jenis_mata_uang',$pembelian->jenis_mata_uang), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('jenis_penempatan', 'Jenis Penempatan*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('jenis_penempatan', old('jenis_penempatan',$pembelian->jenis_penempatan), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('status', 'Status*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::select('status',$status, old('status'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('reksadana_id', 'Reksadana_id*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::select('reksadana_id', $reksadana, old('reksadana_id',$pembelian->reksadana_id), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('user_id', 'User_id*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::select('user_id', $user, old('user_id',$pembelian->user_id), array('class'=>'form-control')) !!}
        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      {!! Form::submit(trans('quickadmin::templates.templates-view_edit-update'), array('class' => 'btn btn-primary')) !!}
      {!! link_to_route('admin.pembelian.index', trans('quickadmin::templates.templates-view_edit-cancel'), null, array('class' => 'btn btn-default')) !!}
    </div>
</div>

{!! Form::close() !!}

@endsection