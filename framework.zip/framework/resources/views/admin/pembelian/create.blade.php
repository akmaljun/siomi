@extends('admin.layouts.master')

@section('content')

<div class="row">


    <div class="col-sm-10 col-sm-offset-2">
        <h1>{{ trans('quickadmin::templates.templates-view_create-add_new') }}</h1>
    </div>

        @if ($errors->any())
        	<div class="alert alert-danger">
        	    <ul>
                    {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
                </ul>
        	</div>
        @endif
    </div>
</div>

{!! Form::open(array('route' => 'admin.pembelian.store', 'id' => 'form-with-validation', 'class' => 'form-horizontal')) !!}

<div class="form-group">
    {!! Form::label('nominal', 'Nominal*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('nominal', old('nominal'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('terbilang', 'Terbilang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('terbilang', old('terbilang'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group">
    {!! Form::label('jenis_mata_uang', 'Jenis Mata Uang*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::select('jenis_mata_uang', $matauang,old('jenis_mata_uang'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('jenis_penempatan', 'Jenis Penempatan*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('jenis_penempatan','Tambah Saldo',old('jenis_penempatan'), array('class'=>'form-control')) !!}

    </div>
</div><div class="form-group">
    {!! Form::label('reksadana_id', 'Reksadana*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::select('reksadana_id', $reksadana, old('reksadana_id'), array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('user_id', 'User_id*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('user_id', Auth::user()->id, array('class'=>'form-control')) !!}
        
    </div>
</div><div class="form-group hidden">
    {!! Form::label('kode_konfirmasi', 'Kode Konfirmasi*', array('class'=>'col-sm-2 control-label')) !!}
    <div class="col-sm-10">
        {!! Form::text('kode_konfirmasi', '', array('class'=>'form-control')) !!}
        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      {!! Form::submit( trans('quickadmin::templates.templates-view_create-create') , array('class' => 'btn btn-primary')) !!}
    </div>
</div>

{!! Form::close() !!}

@endsection