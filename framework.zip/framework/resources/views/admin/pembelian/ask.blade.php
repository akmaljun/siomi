@extends('admin.layouts.master')

@section('content')


<p>{!! link_to_route('admin.konfirmasi.pribadi','DARI REKENING SAYA', array($row->id), array('class' => 'btn btn-xs btn-info')) !!}</p>
  
<p>{!! link_to_route('admin.konfirmasi.orangLain', 'REKENING ORANG LAIN' , array($row->id), array('class' => 'btn btn-success')) !!}</p>


@endsection

