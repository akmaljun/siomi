@extends('admin.layouts.master')

@section('content')



@if(Auth::user()->role_id == 2)
<p>{!! link_to_route('admin.pembelian.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')) !!}</p>
@endif

@if ($pembelian->count())
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption">{{ trans('quickadmin::templates.templates-view_index-list') }}</div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable">
                <thead>
                    <tr>
                       
                        <th>Nominal</th>
<th>Terbilang</th>
<th>Jenis Mata Uang</th>
<th>Jenis Penempatan</th>
<th>Reksadana</th>
<th>Status Persetujuan</th>
@if(Auth::user()->role_id == 4)
<th>&nbsp;</th>

@else
<th>&nbsp;</th>
<th>&nbsp;</th>
@endif                 
                    </tr>
                </thead>

                <tbody>
                    @foreach ($pembelian as $row)
                        <tr>
                            

                            <td>{{ $row->nominal }}</td>
<td>{{ $row->terbilang }}</td>
<td>{{ $row->jenis_mata_uang }}</td>
<td>{{ $row->jenis_penempatan }}</td>
<td>{{ isset($row->reksadana->nama) ? $row->reksadana->nama : '' }}</td>

@if(Auth::user()->role_id == 2 || Auth::user()->role_id == 6 )

<td>{{ isset($row->status) ? $row->status : 'Menunggu Persetujuan' }}</td>

@endif

@if(Auth::user()->role_id == 3 )
    @if($row->status_konfirmasi != null)
        
<td>   {!!  isset($row->status) ? $row->status : link_to_route('admin.pembelian.edit', 'Ubah status', array($row->id), array('class' => 'btn btn-xs btn-info')) !!}</td>

    
    @else
        <td>Menunggu Konfirmasi</td>
@endif
@endif

@if(Auth::user()->role_id == 2 || Auth::user()->role_id == 6 )

<td>{{ isset($row->status_konfirmasi)? 'Telah dikonfirmasi' :  link_to_route('admin.pembelian.konfirmasi','Konfirmasi',array($row->id), array('class' => 'btn btn-xs btn-info')) }}</td>
@endif


@if(Auth::user()->role_id == 3)
<td>{{ isset($row->status_konfirmasi)? link_to_route('admin.pembelian.buktikonfirmasi','Lihat Bukti',array($row->id), array('class' => 'btn btn-xs btn-info')) :  'Belum Dikonfirmasi' }}</td>
@endif



@if(Auth::user()->role_id == 4 )
    <td>   {!!  isset($row->status) ? $row->status : 'Menunggu persetujuan' !!}</td>
@if($row->status == "Disetujui")
<td>{!! link_to_route('admin.pembelian.pdf', 'Lihat', array($row->id), array('class' => 'btn btn-xs btn-info')) !!}</td>
@else
  <td> </td>
@endif
@endif
                          
                        </tr>
                    @endforeach
                </tbody>
            </table>
           
           
        </div>
    </div>
@else
    {{ trans('quickadmin::templates.templates-view_index-no_entries_found') }}
@endif

@endsection

