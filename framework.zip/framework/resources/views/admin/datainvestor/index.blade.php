@extends('admin.layouts.master')

@section('content')

<p>{!! link_to_route('admin.datainvestor.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')) !!}</p>

@if ($datainvestor->count())
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption">{{ trans('quickadmin::templates.templates-view_index-list') }}</div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable">
                <thead>
                    <tr>
                        <th>
                            {!! Form::checkbox('delete_all',1,false,['class' => 'mass']) !!}
                        </th>
                        <th>Nama Lengkap</th>
<th>Tempat Lahir</th>
<th>Tanggal Lahir</th>
<th>Jenis Kelamin</th>
<th>Agama</th>
<th>Status Pernikahan</th>
<th>Nama Suami/Istri</th>
<th>Nama Ahli Waris</th>
<th>Hubungan dengan Ahli Waris</th>
<th>Pendidikan Terakhir</th>
<th>Pekerjaan</th>
<th>Pendapatan Pertahun</th>
<th>Sumber Pendapatan</th>
<th>Tujuan Investasi</th>
<th>Handphone</th>
<th>Telepon</th>
<th>Email</th>
<th>Status</th>

                        <th>&nbsp;</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach ($datainvestor as $row)
                        <tr>
                            <td>
                                {!! Form::checkbox('del-'.$row->id,1,false,['class' => 'single','data-id'=> $row->id]) !!}
                            </td>
                            <td>{{ $row->nama_lengkap }}</td>
<td>{{ $row->tempat_lahir }}</td>
<td>{{ $row->tanggal_lahir }}</td>
<td>{{ $row->jenis_kelamin }}</td>
<td>{{ $row->agama }}</td>
<td>{{ $row->status_pernikahan }}</td>
<td>{{ $row->nama_suami_istri }}</td>
<td>{{ $row->nama_ahli_waris }}</td>
<td>{{ $row->hubungan_ahli_waris }}</td>
<td>{{ $row->pendidikan }}</td>
<td>{{ $row->pekerjaan }}</td>
<td>{{ $row->pendapatan_pertahun }}</td>
<td>{{ $row->sumber_pendapatan }}</td>
<td>{{ $row->tujuan_investasi }}</td>
<td>{{ $row->handphone }}</td>
<td>{{ $row->telepon }}</td>
<td>{{ $row->email }}</td>
<td>{{ $row->status }}</td>

                            <td>
                                {!! link_to_route('admin.datainvestor.edit', trans('quickadmin::templates.templates-view_index-edit'), array($row->id), array('class' => 'btn btn-xs btn-info')) !!}
                                {!! Form::open(array('style' => 'display: inline-block;', 'method' => 'DELETE', 'onsubmit' => "return confirm('".trans("quickadmin::templates.templates-view_index-are_you_sure")."');",  'route' => array('admin.datainvestor.destroy', $row->id))) !!}
                                {!! Form::submit(trans('quickadmin::templates.templates-view_index-delete'), array('class' => 'btn btn-xs btn-danger')) !!}
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="row">
                <div class="col-xs-12">
                    <button class="btn btn-danger" id="delete">
                        {{ trans('quickadmin::templates.templates-view_index-delete_checked') }}
                    </button>
                </div>
            </div>
            {!! Form::open(['route' => 'admin.datainvestor.massDelete', 'method' => 'post', 'id' => 'massDelete']) !!}
                <input type="hidden" id="send" name="toDelete">
            {!! Form::close() !!}
        </div>
	</div>
@else
    {{ trans('quickadmin::templates.templates-view_index-no_entries_found') }}
@endif

@endsection

@section('javascript')
    <script>
        $(document).ready(function () {
            $('#delete').click(function () {
                if (window.confirm('{{ trans('quickadmin::templates.templates-view_index-are_you_sure') }}')) {
                    var send = $('#send');
                    var mass = $('.mass').is(":checked");
                    if (mass == true) {
                        send.val('mass');
                    } else {
                        var toDelete = [];
                        $('.single').each(function () {
                            if ($(this).is(":checked")) {
                                toDelete.push($(this).data('id'));
                            }
                        });
                        send.val(JSON.stringify(toDelete));
                    }
                    $('#massDelete').submit();
                }
            });
        });
    </script>
@stop