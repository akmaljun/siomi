<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2>Status Pencairan</h2>

        <div>
            Terimakasih telah melakukan Penjualan
            Penjualan anda sedang di proses, mohon menunggu 2 hari lagi. Kami akan memberitahu jika penjualan anda telah dicairkan
            <br>
            
            </br>
          

        </div>

    </body>
</html>