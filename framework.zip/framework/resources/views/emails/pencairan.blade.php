<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2>Telah dicairkan</h2>

        <div>
            Terimakasih telah melakukan Penjualan
           Penjualan Anda telah dicairkan dengan nominal {{$jumlahrupiah}} telah dicairkan, silahkan melakukan pembelian kembali.
            <br>
            
            </br>
          

        </div>

    </body>
</html>