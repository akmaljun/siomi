<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2>Verifikasi transaksi Anda</h2>

        <div>
            Terimakasih telah melakukan Transaksi
            Silahkan konfirmasi dengan menggunakan kode konfirmasi berikut 
            <br>
            <h1>{{$kode_konfirmasi}}</h1>
            </br>
          

        </div>

    </body>
</html>