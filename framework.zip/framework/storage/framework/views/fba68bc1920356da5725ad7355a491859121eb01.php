<?php $__env->startSection('content'); ?>



<?php if($konfirmasipembayaran->count()): ?>

    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption">Konfirmasi Pembayaran</div>
        </div>
        <div class="portlet-body">
         <?php foreach($konfirmasipembayaran as $row): ?>
              <div class="col-sm-10">
                <h1>Nomor Rekening :<?php echo e($row->nomor_rekening); ?></h1>
             </div>
             <div class="col-sm-10">
              <h1>Nama Pemegang Rekening :<?php echo e($row->nama_pemegang_rekening); ?></h1>
              </div>
               <div class="col-sm-10">
              <h1>Nama Bank :<?php echo e($row->nama_bank); ?></h1>
            </div>
               <div class="col-sm-10">
             <h1>Cabang : <?php echo e($row->cabang); ?> </h1>
             </div>
              <div class="col-sm-10">
             <h1>Bank Penerima : <?php echo e($row->bank_penerima); ?> </h1>
             </div>
             <div class ="col-sm-10">
             <h1>Bukti Pembayaran : <?php if($row->bukti_pembayaran != ''): ?><img src="<?php echo e(asset('uploads/thumb') . '/'.  $row->bukti_pembayaran); ?>"><?php endif; ?> </h1>
            </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="row">
                <div class="col-xs-12">
                   
                </div>
            </div>
           
        </div>
	</div>
<?php else: ?>
    <?php echo e(trans('quickadmin::templates.templates-view_index-no_entries_found')); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function () {
            $('#delete').click(function () {
                if (window.confirm('<?php echo e(trans('quickadmin::templates.templates-view_index-are_you_sure')); ?>')) {
                    var send = $('#send');
                    var mass = $('.mass').is(":checked");
                    if (mass == true) {
                        send.val('mass');
                    } else {
                        var toDelete = [];
                        $('.single').each(function () {
                            if ($(this).is(":checked")) {
                                toDelete.push($(this).data('id'));
                            }
                        });
                        send.val(JSON.stringify(toDelete));
                    }
                    $('#massDelete').submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>