<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1><?php echo e(trans('quickadmin::templates.templates-view_create-add_new')); ?></h1>

        <?php if($errors->any()): ?>
        	<div class="alert alert-danger">
        	    <ul>
                    <?php echo implode('', $errors->all('<li class="error">:message</li>')); ?>

                </ul>
        	</div>
        <?php endif; ?>
    </div>
</div>

<?php echo Form::open(array('route' => 'admin.datainvestor.store', 'id' => 'form-with-validation', 'class' => 'form-horizontal')); ?>


<div class="form-group">
    <?php echo Form::label('user_id', 'User Id*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::select('user_id', $user, old('user_id'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_lengkap', 'Nama Lengkap*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_lengkap', old('nama_lengkap'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('tempat_lahir', 'Tempat Lahir*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('tempat_lahir', old('tempat_lahir'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('tanggal_lahir', 'Tanggal Lahir*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('tanggal_lahir', old('tanggal_lahir'), array('class'=>'form-control datepicker')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('jenis_kelamin', 'Jenis Kelamin*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('jenis_kelamin', old('jenis_kelamin'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('agama', 'Agama*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('agama', old('agama'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('status_pernikahan', 'Status Pernikahan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('status_pernikahan', old('status_pernikahan'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_suami/istri', 'Nama Suami/Istri*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_suami/istri', old('nama_suami/istri'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_ahli_waris', 'Nama Ahli Waris', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_ahli_waris', old('nama_ahli_waris'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('hubungan_ahli_waris', 'Hubungan dengan Ahli Waris', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('hubungan_ahli_waris', old('hubungan_ahli_waris'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('pendidikan', 'Pendidikan Terakhir*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('pendidikan',''); ?>

        <?php echo Form::checkbox('pendidikan', 1, false); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('pekerjaan', 'Pekerjaan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('pekerjaan',''); ?>

        <?php echo Form::checkbox('pekerjaan', 1, false); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('pendapatan_pertahun', 'Pendapatan Pertahun*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('pendapatan_pertahun',''); ?>

        <?php echo Form::checkbox('pendapatan_pertahun', 1, false); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('sumber_pendapatan', 'Sumber Pendapatan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('sumber_pendapatan',''); ?>

        <?php echo Form::checkbox('sumber_pendapatan', 1, false); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('tujuan_investasi', 'Tujuan Investasi*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('tujuan_investasi',''); ?>

        <?php echo Form::checkbox('tujuan_investasi', 1, false); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('handphone', 'Handphone*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('handphone', old('handphone'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('telepon', 'Telepon*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('telepon', old('telepon'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('email', 'Email*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::email('email', old('email'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('status', 'Status*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('status', old('status'), array('class'=>'form-control')); ?>

        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      <?php echo Form::submit( trans('quickadmin::templates.templates-view_create-create') , array('class' => 'btn btn-primary')); ?>

    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>