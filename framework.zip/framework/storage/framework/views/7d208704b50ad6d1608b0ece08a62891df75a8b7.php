<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->  role_id == 2): ?>
<p><?php echo link_to_route('admin.penjualan.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')); ?></p>
<?php endif; ?>

<?php if($penjualan->count()): ?>
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption"><?php echo e(trans('quickadmin::templates.templates-view_index-list')); ?></div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable">
                <thead>
                    <tr>
                    
                        <th>Nama Investor</th>
<th>Nomor Investor</th>
<th>Nama Reksadana</th>
<th>Jumlah Rupiah</th>
<th>Terbilang</th>
<th>Nomor Rekening</th>
<?php if(Auth::user()->role_id == 2 || Auth::user()->role_id == 3 || Auth::user()->role_id == 4): ?>
<th>Status Konfirmasi</th>
<th></th>

<?php if(Auth::user()->role_id == 2): ?>
<th></th>
<?php endif; ?>



<?php endif; ?>

                       
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($penjualan as $row): ?>
                        <tr>
                          
                            <td><?php echo e($row->NamaInvestor); ?></td>
<td><?php echo e(isset($row->user->id) ? $row->user->id : ''); ?></td>
<td><?php echo e(isset($row->reksadana->nama) ? $row->reksadana->nama: ''); ?></td>

<td><?php echo e($row->jumlahrupiah); ?></td>
<td><?php echo e($row->Terbilang); ?></td>
<td><?php echo e(isset($row->rekening->nomor_rekening) ? $row->rekening->nomor_rekening : ''); ?></td>

<?php if(Auth::user()->role_id == 2): ?>

<td><?php echo e(isset($row->status_konfirmasi)? 'Telah dikonfirmasi' :  link_to_route('admin.penjualan.konfirmasi','Konfirmasi',array($row->id), array('class' => 'btn btn-xs btn-info'))); ?></td>
    <?php if($row->status_konfirmasi): ?>
<td><?php echo e(isset($row->statusPencairan)? 'Telah Dicairkan' :  'Menunggu Pencairan'); ?></td>
 <?php if($row->statusPencairan): ?>
    <td><?php echo link_to_route('admin.penjualan.pdf','LIHAT', array($row->id), array('class' => 'btn btn-xs btn-info')); ?></td>
 <?php else: ?>
 <td></td>
 <?php endif; ?>
<?php else: ?>
<td></td>
<?php endif; ?>
<?php endif; ?>

<?php if(Auth::user()->role_id == 3): ?>
<td><?php echo e(isset($row->status_konfirmasi)? 'Telah Dikonfirmasi' :  'Belum Dikonfirmasi'); ?></td>
<td><?php echo e(isset($row->statusPencairan)? 'Telah dicairkan' :  'Menunggu Pencairan'); ?></td>
<?php endif; ?>


<?php if(Auth::user()->role_id == 4): ?>
<td><?php echo e(isset($row->status_konfirmasi)? 'Telah Dikonfirmasi' :  'Belum Dikonfirmasi'); ?></td>
<?php if($row->status_konfirmasi): ?>
<td><?php echo e(isset($row->statusPencairan)? 'Telah dicairkan' :  link_to_route('admin.penjualan.cairkan','Cairkan',array($row->id), array('class' => 'btn btn-xs btn-info'))); ?></td>
<?php else: ?>
<td></td>
<?php endif; ?>
<?php endif; ?>


                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
           
        </div>
	</div>
<?php else: ?>
    <?php echo e(trans('quickadmin::templates.templates-view_index-no_entries_found')); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>