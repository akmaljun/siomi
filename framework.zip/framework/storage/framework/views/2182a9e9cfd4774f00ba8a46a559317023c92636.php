<?php $__env->startSection('content'); ?>

<div class="row">


    <div class="col-sm-10 col-sm-offset-2">
        <h1><?php echo e(trans('quickadmin::templates.templates-view_create-add_new')); ?></h1>
    </div>

        <?php if($errors->any()): ?>
        	<div class="alert alert-danger">
        	    <ul>
                    <?php echo implode('', $errors->all('<li class="error">:message</li>')); ?>

                </ul>
        	</div>
        <?php endif; ?>
    </div>
</div>

<?php echo Form::open(array('route' => 'admin.pembelian.store', 'id' => 'form-with-validation', 'class' => 'form-horizontal')); ?>


<div class="form-group">
    <?php echo Form::label('nominal', 'Nominal*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nominal', old('nominal'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('terbilang', 'Terbilang*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('terbilang', old('terbilang'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('jenis_mata_uang', 'Jenis Mata Uang*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::select('jenis_mata_uang', $matauang,old('jenis_mata_uang'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group hidden">
    <?php echo Form::label('jenis_penempatan', 'Jenis Penempatan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('jenis_penempatan','Tambah Saldo',old('jenis_penempatan'), array('class'=>'form-control')); ?>


    </div>
</div><div class="form-group">
    <?php echo Form::label('reksadana_id', 'Reksadana*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::select('reksadana_id', $reksadana, old('reksadana_id'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group hidden">
    <?php echo Form::label('user_id', 'User_id*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('user_id', Auth::user()->id, array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group hidden">
    <?php echo Form::label('kode_konfirmasi', 'Kode Konfirmasi*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kode_konfirmasi', '', array('class'=>'form-control')); ?>

        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      <?php echo Form::submit( trans('quickadmin::templates.templates-view_create-create') , array('class' => 'btn btn-primary')); ?>

    </div>
</div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>