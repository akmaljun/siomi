<?php $__env->startSection('content'); ?>



<?php if(Auth::user()->role_id == 2): ?>
<p><?php echo link_to_route('admin.pembelian.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')); ?></p>
<?php endif; ?>

<?php if($pembelian->count()): ?>
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption"><?php echo e(trans('quickadmin::templates.templates-view_index-list')); ?></div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable">
                <thead>
                    <tr>
                       
                        <th>Nominal</th>
<th>Terbilang</th>
<th>Jenis Mata Uang</th>
<th>Jenis Penempatan</th>
<th>Reksadana</th>
<th>Status Persetujuan</th>
<?php if(Auth::user()->role_id == 4): ?>
<th>&nbsp;</th>

<?php else: ?>
<th>&nbsp;</th>
<th>&nbsp;</th>
<?php endif; ?>                 
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($pembelian as $row): ?>
                        <tr>
                            

                            <td><?php echo e($row->nominal); ?></td>
<td><?php echo e($row->terbilang); ?></td>
<td><?php echo e($row->jenis_mata_uang); ?></td>
<td><?php echo e($row->jenis_penempatan); ?></td>
<td><?php echo e(isset($row->reksadana->nama) ? $row->reksadana->nama : ''); ?></td>

<?php if(Auth::user()->role_id == 2 || Auth::user()->role_id == 6 ): ?>

<td><?php echo e(isset($row->status) ? $row->status : 'Menunggu Persetujuan'); ?></td>

<?php endif; ?>

<?php if(Auth::user()->role_id == 3 ): ?>
    <?php if($row->status_konfirmasi != null): ?>
        
<td>   <?php echo isset($row->status) ? $row->status : link_to_route('admin.pembelian.edit', 'Ubah status', array($row->id), array('class' => 'btn btn-xs btn-info')); ?></td>

    
    <?php else: ?>
        <td>Menunggu Konfirmasi</td>
<?php endif; ?>
<?php endif; ?>

<?php if(Auth::user()->role_id == 2 || Auth::user()->role_id == 6 ): ?>

<td><?php echo e(isset($row->status_konfirmasi)? 'Telah dikonfirmasi' :  link_to_route('admin.pembelian.konfirmasi','Konfirmasi',array($row->id), array('class' => 'btn btn-xs btn-info'))); ?></td>
<?php endif; ?>


<?php if(Auth::user()->role_id == 3): ?>
<td><?php echo e(isset($row->status_konfirmasi)? link_to_route('admin.pembelian.buktikonfirmasi','Lihat Bukti',array($row->id), array('class' => 'btn btn-xs btn-info')) :  'Belum Dikonfirmasi'); ?></td>
<?php endif; ?>



<?php if(Auth::user()->role_id == 4 ): ?>
    <td>   <?php echo isset($row->status) ? $row->status : 'Menunggu persetujuan'; ?></td>
<?php if($row->status == "Disetujui"): ?>
<td><?php echo link_to_route('admin.pembelian.pdf', 'Lihat', array($row->id), array('class' => 'btn btn-xs btn-info')); ?></td>
<?php else: ?>
  <td> </td>
<?php endif; ?>
<?php endif; ?>
                          
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
           
           
        </div>
    </div>
<?php else: ?>
    <?php echo e(trans('quickadmin::templates.templates-view_index-no_entries_found')); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>