<?php $__env->startSection('content'); ?>

<!--p><?php echo link_to_route('admin.news.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')); ?></p-->

<?php if($news->count()): ?>
    <div class="portlet box green">
        <div class="portlet-title">
            <div class="caption"><?php echo e(trans('quickadmin::templates.templates-view_index-list')); ?>

			</div>
        </div>
        <div class="portlet-body">
            <table class="table table-striped table-hover table-responsive datatable" id="datatable" border="0.5">                
                    <?php foreach($news as $row): ?>
                        <!--tr>
							<th style='text-align:center; vertical-align:middle' rowspan="5"></th>
						</tr-->						
						<tr>
							<th>Judul</th>
							<td><?php echo e($row->Judul); ?></td>
						</tr>
						<tr>
							<th>Deskripsi</th>
							<td><textarea rows="5" cols="100%"><?php echo e($row->Isi); ?></textarea></td>
						</tr>
						<tr hidden>
							<th>Pembuatan News</th>
							<td><?php echo e(date('d F Y, H:i:s', strtotime($row->created_at))); ?></td>
						</tr>
						<tr hidden>
							<th>Perubahan News</th>
							<td><?php echo e(date('d F Y, H:i:s', strtotime($row->updated_at))); ?></td>
						</tr>
						<tr>
							<th colspan="2"></th>
						</tr>
					<?php endforeach; ?>                
            </table></br>
			<div style='text-align:right; vertical-align:right'>
				<?php echo link_to_route('admin.news.create', trans('quickadmin::templates.templates-view_index-add_new') , null, array('class' => 'btn btn-success')); ?>

				<?php echo link_to_route('admin.news.edit', trans('quickadmin::templates.templates-view_index-edit'), array($row->id), array('class' => 'btn btn-success')); ?>

				<!--<?php echo Form::open(array('style' => 'display: inline-block;', 'method' => 'DELETE', 'onsubmit' => "return confirm('".trans("quickadmin::templates.templates-view_index-are_you_sure")."');",  'route' => array('admin.news.destroy', $row->id))); ?>

                <?php echo Form::submit(trans('quickadmin::templates.templates-view_index-delete'), array('class' => 'btn btn-xs btn-danger')); ?>

				<?php echo Form::close(); ?>-->
			</div>
            <?php echo Form::close(); ?>

        </div>
	</div>
<?php else: ?>
    <?php echo e(trans('quickadmin::templates.templates-view_index-no_entries_found')); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>