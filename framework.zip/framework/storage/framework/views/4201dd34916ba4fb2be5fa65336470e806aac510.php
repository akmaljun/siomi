<html>

<head>

<?php echo $__env->make('admin.partials.javascripts2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('javascript'); ?>

</head>


<body>
<div class="container">
<div class="stepwizard">
    <div class="stepwizard-row setup-panel">
        <div class="stepwizard-step">
            <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
            <p>Step 1</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
            <p>Step 2</p>
        </div>
        <div class="stepwizard-step">
            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
            <p>Step 3</p>
        </div>
          <div class="stepwizard-step">
            <a href="#step-4" type="button" class="btn btn-default btn-circle" disabled="disabled">4</a>
            <p>Step 4</p>
        </div>
          <div class="stepwizard-step">
            <a href="#step-5" type="button" class="btn btn-default btn-circle" disabled="disabled">5</a>
            <p>Step 5</p>
        </div>
    </div>
</div>

<form role="form" method="POST" action="<?php echo e(url('daftar')); ?>" >

  <input type="hidden"
                               name="_token"
                               value="<?php echo e(csrf_token()); ?>">

    <div class="row setup-content" id="step-1">
        <div class="col-xs-12">
            <div class="col-md-12">
                <h3> Step 1</h3>
                <div class="form-group">
                    <label class="control-label">Nama Lengkap</label>
                    <input name="nama_lengkap" maxlength="100" type="text" required="required" class="form-control" placeholder = "Nama Lengkap Anda"  />
                </div>
                <div class="form-group">
                    <label class="control-label">Kewarganegaraan</label>
                    <input name="kewarganegaraan" maxlength="100" type="text" required="required" class="form-control" placeholder="Kewarganegaraan Anda" />
                </div>
                <div class="form-group">
                    <label class="control-label">No Kartu Identitas</label>
                <select class="form-control" name="jenis" required="required">
                    <option>KTP</option>
   					<option>NPWP</option>
   					<option>KITAS</option>
    				<option>PASPOR</option>
  				</select>
                </div>

                <div class="form-group">
                    <label class="control-label">Nomor Identitas</label>
                    <input name="nomor" maxlength="100" type="text" required="required" class="form-control" placeholder="nomor ID Identitas Anda" />
                </div>

                <div class="form-group">
                    <label class="control-label">Tanggal Kadaluarsa</label>
                    <input name="tanggal_kadaluarsa" maxlength="100" type="text" required="required" class="form-control datepicker" placeholder="Tanggal Kadalursa ID Anda" />
                </div>

                <div class="form-group">
                    <label class="control-label">Tempat Lahir</label>
                    <input name="tempat_lahir" maxlength="100" type="text" required="required" class="form-control" placeholder="Tempat Lahir Anda" />
                </div>

                <div class="form-group">
                    <label class="control-label">Tanggal Lahir</label>
                    <input name="tanggal_lahir" maxlength="100" type="text" required="required" class="form-control datepicker" placeholder="Tanggal Lahir Anda" />
                </div>

                <div class="form-group">
                    <label class="control-label">Jenis Kelamin</label>
                <select class="form-control" name="jenis_kelamin" required="required">
                    <option>Laki - Laki</option>
   					<option>Perempuan</option>
  				</select>
                </div>
                
                   <div class="form-group">
                    <label class="control-label">Agama</label>
                    <input name="agama" maxlength="100" type="text" required="required" class="form-control" placeholder="Agama Anda" />
                </div>

               


                 

                <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button>
            </div>
        </div>
    </div>


    <div class="row setup-content" id="step-2">
        <div class="col-xs-12">
            <div class="col-md-12">
                <h3> Step 2</h3>
                <div class="form-group">
                    <label class="control-label">Status Pernikahan</label>
                    <input name="status_pernikahan" maxlength="100" type="text" required="required" class="form-control" placeholder="Status Pernikahan Anda" />
                </div>

                <div class="form-group">
                    <label class="control-label">Nama Suami/Istri</label>
                    <input name="nama_suami_istri" maxlength="100" type="text" required="required" class="form-control" placeholder="Nama Suami/Istri Anda" />
                </div>

                 <div class="form-group">
                    <label class="control-label">Nama Ahli Waris</label>
                    <input name="nama_ahli_waris" maxlength="100" type="text" class="form-control" placeholder="Nama Ahli Waris Anda" />
                </div>

                 <div class="form-group">
                    <label class="control-label">Hubungan Ahli Waris</label>
                    <input name="hubungan_ahli_waris" maxlength="100" type="text" class="form-control" placeholder="Hubungan Ahli Waris Anda" />
                </div>

                <div class="form-group">
                    <label class="control-label">Pendidikan Terakhir</label>
                <select class="form-control" name="pendidikan" required="required">
                    <option>SD</option>
   					<option>SMP</option>
   					<option>SMA</option>
   					<option>D3</option>
   					<option>S1</option>
   					<option>S2</option>
   					<option>S3</option>
   					<option>Lainnya</option>
  				</select>
  				</div>

  				 <div class="form-group">
                    <label class="control-label">Pekerjaan</label>
                <select class="form-control" name="pekerjaan" required="required">
                    <option>Karyawan Biasa</option>
   					<option>Ibu Rumah Tangga</option>
   					<option>Pegawai Negri Sipil</option>
   					<option>Pensiunan</option>
   					<option>Pelajar/Mahasiswa</option>
   					<option>TNI</option>
   					<option>Wiraswasta</option>
   					<option>Polisi</option>
   					<option>Lainnya</option>
  				</select>
                </div>

                 <div class="form-group">
                    <label class="control-label">Pendapatan Pertahun</label>
                <select class="form-control" name="pendapatan_pertahun" required="required">
                    <option><= IDR 10.000.000</option>
   					<option>> IDR 10.000.000 - 50.000.000</option>
   					<option>>IDR 50.000.000 - 100.000.000</option>
   					<option>>IDR 50.000.000 - 100.000.000</option>
   					<option>>IDR 100.000.000 - 500.000.000</option>
   					<option>>IDR 500.000.000 - 1.000.000.000</option>
   					<option>> IDR 1.000.000</option>
  				</select>
                </div>

                   <div class="form-group">
                    <label class="control-label">Sumber Pendapatan</label>
                <select class="form-control" name="sumber_pendapatan" required="required">
                    <option>Gaji</option>
   					<option>Keuntungan Usaha</option>
   					<option>Lainnya</option>
  				</select>
                </div>

                <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button>
            </div>
        </div>
    </div>


    <div class="row setup-content" id="step-3">
        <div class="col-xs-12">
            <div class="col-md-12">
                <h3> Step 3</h3>
                 
                 <div class="form-group">
                    <label class="control-label">Alamat sesuai KTP</label>
                 
                   <div class="form-group">
                     <label class="control-label">Nama Jalan</label>
                    <input name="nama_jalan_ktp" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                     <div class="form-group">
                     <label class="control-label">Kota</label>
                    <input name="kota_ktp" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                     <div class="form-group">
                     <label class="control-label">Propinsi</label>
                    <input name="propinsi_ktp" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                     <div class="form-group">
                     <label class="control-label">Kode Pos</label>
                    <input name="kode_pos_ktp" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                     <div class="form-group">
                       <label class="control-label">Negara</label>
                    <input name="negara_ktp" maxlength="100" type="text" class="form-control" required="required" />
                    </div>
                    </div>

                      <div class="form-group">
                    <label class="control-label">Alamat Sekarang</label>

                    <div class="form-group">
                     <label class="control-label">Nama Jalan</label>
                    <input name="nama_jalan" maxlength="100" type="text" class="form-control " required="required" />
                    </div>

                     <div class="form-group">
                     <label class="control-label">Kota</label>
                    <input name="kota" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                     <div class="form-group">
                     <label class="control-label">Propinsi</label>
                    <input name="propinsi" maxlength="100" type="text" class="form-control" required="required"  />
                    </div>

                     <div class="form-group">
                     <label class="control-label">Kode Pos</label>
                    <input name="kode_pos" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                     <div class="form-group">
                       <label class="control-label">Negara</label>
                    <input name="negara" maxlength="100" type="text" class="form-control" required="required"/>
                    </div>
                    </div>

             
              <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button>
            </div>
        </div>
    </div>


    <div class="row setup-content" id="step-4">
        <div class="col-xs-12">
            <div class="col-md-12">
                <h3> Step 4</h3>
                     <div class="form-group">
                       <label class="control-label">Nama Pemilik Rekening</label>
                    <input name="nama_pemilik_rekening" maxlength="100" type="text" class="form-control" required="required" />
                    </div>


                      <div class="form-group">
                       <label class="control-label">Nomor Rekening</label>
                    <input name="nomor_rekening" maxlength="100" type="text" class="form-control" required="required" />
                    </div>


                      <div class="form-group">
                       <label class="control-label">Nama Bank</label>
                    <input name="nama" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                      <div class="form-group">
                       <label class="control-label">Cabang Bank</label>
                    <input name="cabang" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                <div class="form-group">
                    <label class="control-label">Kurs Rekening</label>
                <select class="form-control" name="jenis_kurs" required="required">
                    <option>Rupiah</option>
   					<option>Dollar</option>
  				</select>
                </div>


                  	<div class="form-group">
                       <label class="control-label">Kode Bank</label>
                    <input name="kode_bank" maxlength="100" type="text" class="form-control" required="required" />
                    </div>
               <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button>
            </div>
        </div>
    </div>



    <div class="row setup-content" id="step-5">
        <div class="col-xs-12">
            <div class="col-md-12">
                <h3> Step 5</h3>

                         <div class="form-group">
                       <label class="control-label">Handphone</label>
                    <input name="handphone" maxlength="100" type="text" class="form-control" required="required"/>
                    </div>

                      <div class="form-group">
                       <label class="control-label">Telepon</label>
                    <input name="telepon" maxlength="100" type="text" class="form-control" required="required"/>
                    </div>

                      <div class="form-group">
                       <label class="control-label">EMAIL</label>
                    <input name="email" maxlength="100" type="text" class="form-control" required="required" />
                    </div>

                 <div class="form-group">
                    <label class="control-label">Tujuan Investasi</label>
                <select class="form-control" name="tujuan_investasi" required="required">
                    <option>Investasi</option>
   					<option>Penghasilan</option>
   					<option>Kenaikan Harga</option>
   					<option>Lainnya</option>
  				</select>
                </div>


                   <div class="form-group">
                       <label class="control-label">Notes</label>
                    <textarea name="note" maxlength="100" type="text" class="form-control"></textarea>
                    </div>

                    

                <button class="btn btn-success btn-lg pull-right" type="submit" >Finish!</button>
            
            </div>
        </div>
    </div>

</form>
</div>
</body>
</html>