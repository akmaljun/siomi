
<div class="row">
    <div class="col-sm-10 col-sm-offset-2">
        <h1>DAFTAR</h1>

        <?php if($errors->any()): ?>
        	<div class="alert alert-danger">
        	    <ul>
                    <?php echo implode('', $errors->all('<li class="error">:message</li>')); ?>

                </ul>
        	</div>
        <?php endif; ?>
    </div>
</div>

<?php echo Form::open(array('route' => 'admin.datainvestor.store', 'id' => 'form-with-validation', 'class' => 'form-horizontal')); ?>


<div class="form-group">
    <?php echo Form::label('nama_lengkap', 'Nama Lengkap*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_lengkap', old('nama_lengkap'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kewarganegaraan', 'Kewarganegaraan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kewarganegaraan', old('kewarganegaraan'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('jenis', 'No Kartu Identitas', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('jenis',''); ?>

        <?php echo Form::checkbox('jenis', 'KTP', false); ?>

    <div>
        <?php echo Form::label('jenis', 'KTP :'); ?>

         <?php echo Form::text('nomor', old('nomor'), array('class'=>'form-control')); ?>


         <?php echo Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')); ?>

          <?php echo Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')); ?>



        <?php echo Form::checkbox('jenis', 'NPWP', false); ?>

        <?php echo Form::label('jenis', 'NPWP :'); ?>

         <?php echo Form::text('nomor', old('nomor'), array('class'=>'form-control')); ?>

          <?php echo Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')); ?>

          <?php echo Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')); ?>



        <?php echo Form::checkbox('jenis', 'KITAS', false); ?>

        <?php echo Form::label('jenis', 'KITAS :'); ?>

         <?php echo Form::text('nomor', old('nomor'), array('class'=>'form-control')); ?>

          <?php echo Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')); ?>

          <?php echo Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')); ?>



        <?php echo Form::checkbox('jenis', 'Paspor', false); ?>

        <?php echo Form::label('jenis', 'Paspor :'); ?>

         <?php echo Form::text('nomor', old('nomor'), array('class'=>'form-control')); ?>

          <?php echo Form::label('tanggal_kadaluarsa', 'Tanggal Kadaluarsa*', array('class'=>'col-sm-2 control-label')); ?>

          <?php echo Form::text('tanggal_kadaluarsa', old('tanggal_kadaluarsa'), array('class'=>'form-control datepicker')); ?>



        
    </div>
</div><div class="form-group">
    <?php echo Form::label('tempat_lahir', 'Tempat Lahir*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('tempat_lahir', old('tempat_lahir'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('tanggal_lahir', 'Tanggal Lahir*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('tanggal_lahir', old('tanggal_lahir'), array('class'=>'form-control datepicker')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('jenis_kelamin', 'Jenis Kelamin*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('jenis_kelamin', old('jenis_kelamin'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('agama', 'Agama*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('agama', old('agama'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('status_pernikahan', 'Status Pernikahan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('status_pernikahan', old('status_pernikahan'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_suami/istri', 'Nama Suami/Istri*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_suami/istri', old('nama_suami/istri'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_ahli_waris', 'Nama Ahli Waris', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_ahli_waris', old('nama_ahli_waris'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('hubungan_ahli_waris', 'Hubungan dengan Ahli Waris', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('hubungan_ahli_waris', old('hubungan_ahli_waris'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('pendidikan', 'Pendidikan Terakhir*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('pendidikan',''); ?>

        <?php echo Form::checkbox('pendidikan', 'SD', false); ?>

         <?php echo Form::label('pendidikan', 'SD'); ?>

        <?php echo Form::checkbox('pendidikan', 'SMA', false); ?>

         <?php echo Form::label('pendidikan', 'SMA'); ?>

        <?php echo Form::checkbox('pendidikan', 'D3', false); ?>

         <?php echo Form::label('pendidikan', 'D3'); ?>

        </div> 
    <div class="col-sm-10">
        <?php echo Form::checkbox('pendidikan', 'S1', false); ?>

         <?php echo Form::label('pendidikan', 'S1'); ?>

        <?php echo Form::checkbox('pendidikan', 'S2', false); ?>

         <?php echo Form::label('pendidikan', 'S2'); ?>

        <?php echo Form::checkbox('pendidikan', 'S3', false); ?>

         <?php echo Form::label('pendidikan', 'S3'); ?>

        <?php echo Form::checkbox('pendidikan', 'Lainnya', false); ?>

         <?php echo Form::label('pendidikan', 'Lainnya'); ?>

    </div>
</div><div class="form-group">
    <?php echo Form::label('pekerjaan', 'Pekerjaan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('pekerjaan',''); ?>

        <?php echo Form::checkbox('pekerjaan', 'Karyawan Biasa', false); ?>

         <?php echo Form::label('pekerjaan', 'Karyawan Biasa'); ?>


        <?php echo Form::checkbox('pekerjaan', 'Ibu Rumah Tangga', false); ?>

         <?php echo Form::label('pendidikan', 'Ibu Rumah Tangga'); ?>


        <?php echo Form::checkbox('pekerjaan', 'Pegawai Negri Sipil', false); ?>

         <?php echo Form::label('pendidikan', 'Pegawai Negri Sipil'); ?>


        <?php echo Form::checkbox('pekerjaan', 'Pensiunan', false); ?>

         <?php echo Form::label('pendidikan', 'Pensiunan'); ?>


        <?php echo Form::checkbox('pekerjaan', 'Pelajar/Mahasiswa', false); ?>

         <?php echo Form::label('pendidikan', 'Pelajar/Mahasiswa'); ?>


        <?php echo Form::checkbox('pekerjaan', 'TNI', false); ?>

         <?php echo Form::label('pendidikan', 'TNI'); ?>


        <?php echo Form::checkbox('pekerjaan', 'Wiraswasta', false); ?>

         <?php echo Form::label('pendidikan', 'Wiraswasta'); ?>


        <?php echo Form::checkbox('pekerjaan', 'Polisi', false); ?>

         <?php echo Form::label('pendidikan', 'Polisi'); ?>


         <?php echo Form::checkbox('pekerjaan', 'Lainnya', false); ?>

         <?php echo Form::label('pendidikan', 'Lainnya'); ?>


    </div>
</div><div class="form-group">
    <?php echo Form::label('pendapatan_pertahun', 'Pendapatan Pertahun*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('pendapatan_pertahun',''); ?>

              <?php echo Form::checkbox('pendapatan_pertahun', '<= IDR 10.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '<= IDR 10.000.000'); ?>


        <?php echo Form::checkbox('pendapatan_pertahun', '> IDR 10.000.000 - 50.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '> IDR 10.000.000 - 50.000.000'); ?>


        <?php echo Form::checkbox('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000'); ?>


        <?php echo Form::checkbox('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '>IDR 50.000.000 - 100.000.000'); ?>


        <?php echo Form::checkbox('pendapatan_pertahun', '>IDR 100.000.000 - 500.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '>IDR 100.000.000 - 500.000.000'); ?>


        <?php echo Form::checkbox('pendapatan_pertahun', '>IDR 500.000.000 - 1.000.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '>IDR 500.000.000 - 1.000.000.000'); ?>


        <?php echo Form::checkbox('pendapatan_pertahun', '> IDR 1.000.000', false); ?>

         <?php echo Form::label('pendapatan_pertahun', '> IDR 1.000.000'); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('sumber_pendapatan', 'Sumber Pendapatan*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('sumber_pendapatan',''); ?>

        
        <?php echo Form::checkbox('sumber_pendapatan', 'gaji', false); ?>

        <?php echo Form::label('sumber_pendapatan', 'Gaji'); ?>


        <?php echo Form::checkbox('sumber_pendapatan', 'keuntungan usaha', false); ?>

        <?php echo Form::label('sumber_pendapatan', 'Keuntungan Usaha'); ?>


        <?php echo Form::checkbox('sumber_pendapatan', 'lainnya', false); ?>

        <?php echo Form::label('sumber_pendapatan', 'Lainnya'); ?>

    
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_jalan', 'Alamat sesuai KTP*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_jalan', old('nama_jalan'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kota', 'Kota*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kota', old('kota'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('provinsi', 'Provinsi*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('provinsi', old('provinsi'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kode_pos', 'Kode Pos*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kode_pos', old('kode_pos'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('negara', 'Negara*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('negara', old('negara'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_jalan', 'Alamat Koresponden*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama_jalan', old('nama_jalan'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kota', 'Kota*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kota', old('kota'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('provinsi', 'Provinsi*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('provinsi', old('provinsi'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kode_pos', 'Kode Pos*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kode_pos', old('kode_pos'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('negara', 'Negara*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('negara', old('negara'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('handphone', 'Handphone*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('handphone', old('handphone'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('telepon', 'Telepon*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('telepon', old('telepon'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('email', 'Email*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::email('email', old('email'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('tujuan_investasi', 'Tujuan Investasi*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::hidden('tujuan_investasi',''); ?>

        <?php echo Form::checkbox('tujuan_investasi','Investasi', false); ?>

         <?php echo Form::label('sumber_pendapatan', 'Investasi'); ?>


        <?php echo Form::checkbox('tujuan_investasi','Penghasilan', false); ?>

         <?php echo Form::label('sumber_pendapatan', 'Penghasilan'); ?>


        <?php echo Form::checkbox('tujuan_investasi','Kenaikan Harga', false); ?>

         <?php echo Form::label('sumber_pendapatan', 'Kenaikan Harga'); ?>


        <?php echo Form::checkbox('tujuan_investasi','Lainnya', false); ?>

         <?php echo Form::label('sumber_pendapatan', 'Lainnya	'); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('datainvestor_id', 'Investor_id*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="form-group">
    <?php echo Form::label('nama_pemilik_rekening', 'Nama Pemilik Rekening', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama', 'Nama*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama', old('nama'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('cabang', old('cabang'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kurs_rekening', 'Kurs Rekening', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kurs_rekening', old('kurs_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kode_bank', 'Kode Bank*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kode_bank', old('kode_bank'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_pemilik_rekening', 'Nama Pemilik Rekening', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('rekening_id', 'rekening_id*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="form-group">
    <?php echo Form::label('nama', 'Nama*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama', old('nama'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('cabang', old('cabang'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kurs_rekening', 'Kurs Rekening', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kurs_rekening', old('kurs_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kode_bank', 'Kode Bank*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kode_bank', old('kode_bank'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama_pemilik_rekening', 'Nama Pemilik Rekening', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nomor_rekening', 'Nomor Rekening*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nomor_rekening', old('nomor_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('nama', 'Nama*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('nama', old('nama'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('cabang', 'Cabang*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('cabang', old('cabang'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kurs_rekening', 'Kurs Rekening', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kurs_rekening', old('kurs_rekening'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('kode_bank', 'Kode Bank*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('kode_bank', old('kode_bank'), array('class'=>'form-control')); ?>

        
    </div>
</div><div class="form-group">
    <?php echo Form::label('status', 'Status*', array('class'=>'col-sm-2 control-label')); ?>

    <div class="col-sm-10">
        <?php echo Form::text('status', old('status'), array('class'=>'form-control')); ?>

        
    </div>
</div>

<div class="form-group">
    <div class="col-sm-10 col-sm-offset-2">
      <?php echo Form::submit( trans('quickadmin::templates.templates-view_create-create') , array('class' => 'btn btn-primary')); ?>

    </div>
</div>

<?php echo Form::close(); ?>


